"""Índices espectrales y extracción de cuerpos de agua sin arcpy.

Reescritura de ProcessingService.cs: en ArcGIS Pro esto corre sobre
Spatial Analyst (sa.RasterCalculator). Aquí se hace álgebra de bandas
directa con GDAL/numpy — misma fórmula, sin depender de ninguna extensión
con licencia aparte.

Limitación conocida vs. la versión de Pro: el paso de suavizado de polígonos
(cartography.SmoothPolygon / PAEK) no está portado todavía; el polígono de
agua sale del polygonize crudo, filtrado por área mínima.
"""
import os
from enum import Enum
from typing import Optional

import numpy as np
from osgeo import gdal, ogr, osr

from .dataset_catalog import CloudMaskType, DatasetInfo

gdal.UseExceptions()


class IndexType(Enum):
    NDVI = "NDVI"
    BSI = "BSI"
    NDWI = "NDWI"
    MNDWI = "MNDWI"


def find_band(folder: str, suffix: str) -> Optional[str]:
    if not suffix or not os.path.isdir(folder):
        return None
    matches = []
    for root, _dirs, files in os.walk(folder):
        for name in files:
            ext = os.path.splitext(name)[1].lower()
            if ext in (".tif", ".tiff", ".jp2") and suffix.lower() in os.path.splitext(name)[0].lower():
                matches.append(os.path.join(root, name))
    if not matches:
        return None
    matches.sort(key=len)
    return matches[0]


def _read_band(path: str):
    ds = gdal.Open(path)
    if ds is None:
        raise FileNotFoundError(f"No se pudo abrir la banda: {path}")
    arr = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    return ds, arr


def _write_raster(path: str, array: np.ndarray, like_ds, nodata: float = -9999.0, band_count: int = 1):
    driver = gdal.GetDriverByName("GTiff")
    if array.ndim == 2:
        array = array[np.newaxis, ...]
    out = driver.Create(path, like_ds.RasterXSize, like_ds.RasterYSize, array.shape[0], gdal.GDT_Float32)
    out.SetGeoTransform(like_ds.GetGeoTransform())
    out.SetProjection(like_ds.GetProjection())
    for i in range(array.shape[0]):
        band = out.GetRasterBand(i + 1)
        band.WriteArray(np.nan_to_num(array[i], nan=nodata))
        band.SetNoDataValue(nodata)
    out.FlushCache()
    return path


def _require_bands(**bands):
    missing = [name for name, path in bands.items() if not path]
    if missing:
        raise FileNotFoundError(
            "No se encontraron todas las bandas necesarias en la carpeta de la escena "
            f"(faltan: {', '.join(missing)}). Verifica que el paquete se descomprimió."
        )


def _norm(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    with np.errstate(divide="ignore", invalid="ignore"):
        return (a - b) / (a + b)


def calculate_index(index: IndexType, scene_folder: str, dataset: DatasetInfo, output_raster: str) -> str:
    b = dataset.bands
    if b is None:
        raise ValueError("El dataset no tiene mapeo de bandas.")

    blue_p = find_band(scene_folder, b.blue)
    green_p = find_band(scene_folder, b.green)
    red_p = find_band(scene_folder, b.red)
    nir_p = find_band(scene_folder, b.nir)
    swir1_p = find_band(scene_folder, b.swir1)

    if index == IndexType.NDVI:
        _require_bands(nir=nir_p, red=red_p)
        ds, nir = _read_band(nir_p)
        _, red = _read_band(red_p)
        result = _norm(nir, red)
    elif index == IndexType.NDWI:
        _require_bands(green=green_p, nir=nir_p)
        ds, green = _read_band(green_p)
        _, nir = _read_band(nir_p)
        result = _norm(green, nir)
    elif index == IndexType.MNDWI:
        _require_bands(green=green_p, swir1=swir1_p)
        ds, green = _read_band(green_p)
        _, swir1 = _read_band(swir1_p)
        result = _norm(green, swir1)
    elif index == IndexType.BSI:
        _require_bands(swir1=swir1_p, red=red_p, nir=nir_p, blue=blue_p)
        ds, swir1 = _read_band(swir1_p)
        _, red = _read_band(red_p)
        _, nir = _read_band(nir_p)
        _, blue = _read_band(blue_p)
        with np.errstate(divide="ignore", invalid="ignore"):
            result = ((swir1 + red) - (nir + blue)) / ((swir1 + red) + (nir + blue))
    else:
        raise ValueError(f"Índice no soportado: {index}")

    return _write_raster(output_raster, result, ds)


def make_composite(scene_folder: str, dataset: DatasetInfo, mode: str) -> str:
    b = dataset.bands
    if b is None:
        raise ValueError("El dataset no tiene mapeo de bandas.")
    m = (mode or "natural").lower()

    if m.startswith("swir") or "agua" in m:
        suffixes, tag = (b.swir1, b.nir, b.red), "SWIR_Agua"
    elif m.startswith("falso"):
        suffixes, tag = (b.nir, b.red, b.green), "FalsoColor"
    else:
        suffixes, tag = (b.red, b.green, b.blue), "ColorNatural"

    paths = [find_band(scene_folder, s) for s in suffixes]
    _require_bands(**{f"banda_{i}": p for i, p in enumerate(paths)})

    ds0, arr0 = _read_band(paths[0])
    stack = [arr0] + [_read_band(p)[1] for p in paths[1:]]
    out_path = os.path.join(scene_folder, f"{tag}_RGB.tif")
    return _write_raster(out_path, np.stack(stack), ds0)


def extract_water(
    scene_folder: str, dataset: DatasetInfo, output_vector: str,
    threshold: float = 0.0, min_area_sq_meters: float = 1000.0,
    ndvi_max: float = 0.3, swir_threshold: float = 1300.0,
) -> str:
    b = dataset.bands
    if b is None:
        raise ValueError("El dataset no tiene mapeo de bandas.")

    green_p = find_band(scene_folder, b.green)
    swir1_p = find_band(scene_folder, b.swir1)
    red_p = find_band(scene_folder, b.red)
    nir_p = find_band(scene_folder, b.nir)
    _require_bands(green=green_p, swir1=swir1_p, red=red_p, nir=nir_p)

    ds, green = _read_band(green_p)
    _, swir1 = _read_band(swir1_p)
    _, red = _read_band(red_p)
    _, nir = _read_band(nir_p)

    with np.errstate(divide="ignore", invalid="ignore"):
        mndwi = (green - swir1) / (green + swir1)
        ndwi = (green - nir) / (green + nir)
        ndvi = (nir - red) / (nir + red)

    agua_esp = ((mndwi > threshold) | (ndwi > 0)) & (ndvi < ndvi_max)

    cloud_band_path = None
    if dataset.cloud_mask_band:
        cloud_band_path = find_band(scene_folder, dataset.cloud_mask_band)

    agua = agua_esp
    cloudfree = np.ones_like(agua, dtype=bool)
    if cloud_band_path and dataset.cloud_mask == CloudMaskType.SENTINEL_SCL:
        _, scl = _read_band(cloud_band_path)
        scl_i = scl.astype(np.int32)
        swir_low = (swir1 < swir_threshold) & (ndvi < 0.15)
        agua = agua_esp | swir_low | (scl_i == 6)
        cloudfree = ~np.isin(scl_i, [3, 8, 9, 10, 11])
    elif cloud_band_path and dataset.cloud_mask == CloudMaskType.LANDSAT_QA:
        _, qa = _read_band(cloud_band_path)
        qa_i = qa.astype(np.int32)
        cloudfree = (
            ((qa_i.astype(np.int64) & 8) == 0)
            & ((qa_i.astype(np.int64) & 16) == 0)
            & ((qa_i.astype(np.int64) & 4) == 0)
        )

    mask = (agua & cloudfree).astype(np.uint8)

    return _polygonize_mask(mask, ds, output_vector, min_area_sq_meters)


def _polygonize_mask(mask: np.ndarray, like_ds, output_vector: str, min_area_sq_meters: float) -> str:
    mem_driver = gdal.GetDriverByName("MEM")
    mask_ds = mem_driver.Create("", like_ds.RasterXSize, like_ds.RasterYSize, 1, gdal.GDT_Byte)
    mask_ds.SetGeoTransform(like_ds.GetGeoTransform())
    mask_ds.SetProjection(like_ds.GetProjection())
    mask_ds.GetRasterBand(1).WriteArray(mask)

    srs = osr.SpatialReference()
    srs.ImportFromWkt(like_ds.GetProjection())

    out_driver = ogr.GetDriverByName("GPKG")
    if os.path.exists(output_vector):
        out_driver.DeleteDataSource(output_vector)
    out_ds = out_driver.CreateDataSource(output_vector)
    layer = out_ds.CreateLayer("agua", srs=srs, geom_type=ogr.wkbPolygon)
    layer.CreateField(ogr.FieldDefn("value", ogr.OFTInteger))

    band = mask_ds.GetRasterBand(1)
    gdal.Polygonize(band, band, layer, 0, [], callback=None)

    # Filtrar por área mínima y por value==1 (agua), en una segunda pasada.
    to_delete = []
    for feature in layer:
        geom = feature.GetGeometryRef()
        if feature.GetField("value") != 1 or geom is None or geom.GetArea() < min_area_sq_meters:
            to_delete.append(feature.GetFID())
    for fid in to_delete:
        layer.DeleteFeature(fid)
    layer.SyncToDisk()
    out_ds = None
    return output_vector
