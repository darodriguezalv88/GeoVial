"""Widgets reutilizables para elegir varias capas (ejes, redes) desde el
proyecto QGIS actual, en vez de escribir rutas a mano como en ArcGIS Pro."""
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QHBoxLayout, QLineEdit, QPushButton, QVBoxLayout, QWidget,
)


class NamedLayerListWidget(QWidget):
    """Filas de (nombre, capa) — para los ejes/alternativas (ALT1, ALT2, ...)."""

    def __init__(self, geometry_filter=QgsMapLayerProxyModel.LineLayer, parent=None):
        super().__init__(parent)
        self._geometry_filter = geometry_filter
        self._rows = []
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._rows_layout = QVBoxLayout()
        self._layout.addLayout(self._rows_layout)
        add_btn = QPushButton("+ Agregar eje")
        add_btn.clicked.connect(lambda: self.add_row())
        self._layout.addWidget(add_btn)
        self.add_row()

    def add_row(self, name: str = None):
        row = QWidget()
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        name_edit = QLineEdit(name or f"ALT{len(self._rows) + 1}")
        name_edit.setMaximumWidth(70)
        combo = QgsMapLayerComboBox()
        combo.setFilters(self._geometry_filter)
        remove_btn = QPushButton("✕")
        remove_btn.setMaximumWidth(24)
        row_layout.addWidget(name_edit)
        row_layout.addWidget(combo, 1)
        row_layout.addWidget(remove_btn)
        self._rows_layout.addWidget(row)
        entry = (row, name_edit, combo)
        self._rows.append(entry)
        remove_btn.clicked.connect(lambda: self._remove_row(entry))

    def _remove_row(self, entry):
        if len(self._rows) <= 1:
            return
        row, _name_edit, _combo = entry
        self._rows.remove(entry)
        row.setParent(None)
        row.deleteLater()

    def values(self) -> dict:
        out = {}
        for _row, name_edit, combo in self._rows:
            layer = combo.currentLayer()
            name = name_edit.text().strip()
            if layer is not None and name:
                out[name] = layer
        return out


class FilterableLayerListWidget(QWidget):
    """Filas de (capa, campo_filtro opcional, valor_filtro opcional) — para
    las capas de red de un sector (HS/HC), que pueden venir de varias
    fuentes con filtros distintos cada una."""

    def __init__(self, geometry_filter=QgsMapLayerProxyModel.LineLayer, parent=None):
        super().__init__(parent)
        self._geometry_filter = geometry_filter
        self._rows = []
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._rows_layout = QVBoxLayout()
        self._layout.addLayout(self._rows_layout)
        add_btn = QPushButton("+ Agregar capa")
        add_btn.clicked.connect(lambda: self.add_row())
        self._layout.addWidget(add_btn)
        self.add_row()

    def add_row(self):
        row = QWidget()
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        combo = QgsMapLayerComboBox()
        combo.setFilters(self._geometry_filter)
        campo_edit = QLineEdit()
        campo_edit.setPlaceholderText("campo filtro (opcional)")
        valor_edit = QLineEdit()
        valor_edit.setPlaceholderText("valor")
        remove_btn = QPushButton("✕")
        remove_btn.setMaximumWidth(24)
        row_layout.addWidget(combo, 2)
        row_layout.addWidget(campo_edit, 1)
        row_layout.addWidget(valor_edit, 1)
        row_layout.addWidget(remove_btn)
        self._rows_layout.addWidget(row)
        entry = (row, combo, campo_edit, valor_edit)
        self._rows.append(entry)
        remove_btn.clicked.connect(lambda: self._remove_row(entry))

    def _remove_row(self, entry):
        if len(self._rows) <= 1:
            return
        row = entry[0]
        self._rows.remove(entry)
        row.setParent(None)
        row.deleteLater()

    def values(self):
        """Devuelve [(layer, campo_or_None, valor_or_None), ...] para las filas con capa elegida."""
        out = []
        for _row, combo, campo_edit, valor_edit in self._rows:
            layer = combo.currentLayer()
            if layer is None:
                continue
            campo = campo_edit.text().strip() or None
            valor = valor_edit.text().strip() or None
            out.append((layer, campo, valor))
        return out
