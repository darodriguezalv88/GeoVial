"""Punto único de "gating" de licencia, igual que LicenseGate.cs en el
add-in de ArcGIS Pro: se llama al inicio de CUALQUIER herramienta comercial
(satelital, abscisas, drenaje, puentes, redes, carto25k). No cubre el botón
de licencia en sí (siempre accesible).
"""
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import QMessageBox

from ..core import license_service, update_check

_trial_warning_shown = False
_update_notice_shown = False


def _maybe_show_update_notice(parent):
    global _update_notice_shown
    if _update_notice_shown:
        return
    info = update_check.cached_update_info()
    if not info or not info.available:
        return
    _update_notice_shown = True

    msg = f"Hay una nueva versión de GeoVial disponible ({info.latest_version}).\n\n"
    if info.notes:
        msg += info.notes + "\n\n"
    msg += "¿Quieres ir a descargarla ahora?"
    result = QMessageBox.question(
        parent, "Actualización disponible", msg, QMessageBox.Yes | QMessageBox.No
    )
    if result == QMessageBox.Yes and info.download_url:
        QDesktopServices.openUrl(QUrl(info.download_url))


def ensure_usable(parent) -> bool:
    """Llamar al inicio de cada acción de herramienta. Devuelve False si el
    trial venció y no hay licencia válida — en ese caso, la herramienta que
    llama debe abortar sin ejecutar nada."""
    global _trial_warning_shown

    update_check.kick_off_check_if_needed()
    _maybe_show_update_notice(parent)

    trial_days = license_service.trial_days_remaining()

    if trial_days > 0:
        if trial_days <= 1 and not _trial_warning_shown:
            _trial_warning_shown = True
            QMessageBox.information(
                parent, "Prueba por vencer",
                "Hoy es tu último día de prueba de GeoVial. Adquiere un plan mensual o "
                "anual desde el botón \"Licencia\" para seguir usando las herramientas "
                "sin interrupciones.",
            )
        return True

    if license_service.is_licensed():
        return True

    QMessageBox.warning(
        parent, "Prueba finalizada",
        "Tu periodo de prueba de GeoVial (3 días) ha finalizado.\n\n"
        "Adquiere un plan mensual o anual desde el botón \"Licencia\" para seguir "
        "usando las herramientas.",
    )
    return False
