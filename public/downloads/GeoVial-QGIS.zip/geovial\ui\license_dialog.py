from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLabel, QLineEdit, QPushButton,
    QDialogButtonBox, QMessageBox, QTabWidget, QWidget,
)

from ..core import license_service

WEBSITE_URL = "https://geovialpro.com/precios"


class LicenseDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Licencia de GeoVial")
        self.setMinimumWidth(420)

        layout = QVBoxLayout(self)

        status = license_service.get_status()
        self.status_label = QLabel(
            f"<b>Estado:</b> {status.status_label}<br>{status.summary}<br>"
            f"<small>Hardware ID: {status.hardware_id}</small>"
        )
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        tabs = QTabWidget()
        layout.addWidget(tabs)

        # --- Pestaña: activar clave existente ---
        activate_tab = QWidget()
        activate_form = QFormLayout(activate_tab)
        self.key_edit = QLineEdit(status.license_key or "")
        activate_form.addRow("Clave de licencia:", self.key_edit)
        activate_btn = QPushButton("Activar")
        activate_btn.clicked.connect(self._on_activate)
        activate_form.addRow(activate_btn)
        tabs.addTab(activate_tab, "Activar clave")

        # --- Pestaña: comprar un plan ---
        buy_tab = QWidget()
        buy_form = QFormLayout(buy_tab)
        buy_label = QLabel(
            "Elige un plan mensual o anual en nuestra web y recibirás tu clave de "
            "licencia por correo para activarla aquí."
        )
        buy_label.setWordWrap(True)
        buy_form.addRow(buy_label)
        buy_btn = QPushButton("Ver planes y precios")
        buy_btn.clicked.connect(self._open_website)
        buy_form.addRow(buy_btn)
        tabs.addTab(buy_tab, "Comprar licencia")

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self.accept)
        layout.addWidget(buttons)

    def _on_activate(self):
        result = license_service.activate(self.key_edit.text())
        if result.success:
            QMessageBox.information(self, "Licencia", result.message)
            self.accept()
        else:
            QMessageBox.warning(self, "Licencia", result.message)

    def _open_website(self):
        QDesktopServices.openUrl(QUrl(WEBSITE_URL))
