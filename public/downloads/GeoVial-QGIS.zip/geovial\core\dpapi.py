"""Envoltorio de CryptProtectData/CryptUnprotectData (DPAPI) via ctypes.

Puerto directo del uso que hace el add-in de ArcGIS Pro de
System.Security.Cryptography.ProtectedData (mismo algoritmo subyacente:
DPAPI con entropía adicional, ámbito CurrentUser), para que los archivos
cifrados sean equivalentes en concepto aunque no binariamente intercambiables
entre C# y Python (cada runtime serializa el JSON antes de cifrar).
"""
import ctypes
import ctypes.wintypes as wt

_crypt32 = ctypes.WinDLL("crypt32")
_kernel32 = ctypes.WinDLL("kernel32")


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _blob(data: bytes) -> _DATA_BLOB:
    buf = ctypes.create_string_buffer(data, len(data))
    return _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))


def _blob_to_bytes(blob: _DATA_BLOB) -> bytes:
    out = ctypes.string_at(blob.pbData, blob.cbData)
    _kernel32.LocalFree(blob.pbData)
    return out


def protect(data: bytes, entropy: bytes) -> bytes:
    in_blob = _blob(data)
    entropy_blob = _blob(entropy)
    out_blob = _DATA_BLOB()
    ok = _crypt32.CryptProtectData(
        ctypes.byref(in_blob), None, ctypes.byref(entropy_blob),
        None, None, 0, ctypes.byref(out_blob),
    )
    if not ok:
        raise ctypes.WinError()
    return _blob_to_bytes(out_blob)


def unprotect(data: bytes, entropy: bytes) -> bytes:
    in_blob = _blob(data)
    entropy_blob = _blob(entropy)
    out_blob = _DATA_BLOB()
    ok = _crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, ctypes.byref(entropy_blob),
        None, None, 0, ctypes.byref(out_blob),
    )
    if not ok:
        raise ctypes.WinError()
    return _blob_to_bytes(out_blob)
