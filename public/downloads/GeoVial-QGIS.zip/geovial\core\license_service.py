"""Lógica de licenciamiento: trial + activación/validación online.

Puerto de LicenseService.cs. Mismo backend (GeoVialWeb) y mismos endpoints
que usa el add-in de ArcGIS Pro: /api/license/activate|validate.
Mismas reglas de negocio: trial de 3 días desde el primer uso, luego exige
activar una licencia paga con machine-binding (1 dispositivo por licencia).
"""
from datetime import datetime, timedelta, timezone
from typing import NamedTuple, Optional

import requests

from . import hardware_id, license_store
from .license_store import LicenseState

BACKEND_BASE_URL = "https://geovialpro.com"

TRIAL_DAYS = 3
OFFLINE_GRACE_DAYS = 7
HTTP_TIMEOUT = 5

ADDIN_VERSION = "1.0-beta"
ADDIN_DESCRIPTION = (
    "Herramientas SIG para estudios de prefactibilidad y diseño de corredores viales."
)
LICENSED_FEATURES = [
    "Imágenes satelitales (Landsat / Sentinel-2, DEM)",
    "Índices espectrales y extracción de cuerpos de agua",
]


class ActivationResult(NamedTuple):
    success: bool
    message: str


class LicenseStatus(NamedTuple):
    trial_days_remaining: int
    has_key: bool
    licensed: bool
    license_key: Optional[str]
    hardware_id: str
    trial_end_date_local: Optional[datetime]
    activated_date_local: Optional[datetime]

    @property
    def status_label(self) -> str:
        if self.licensed:
            return "Activa"
        return "Prueba" if self.trial_days_remaining > 0 else "Vencida"

    @property
    def summary(self) -> str:
        if self.licensed:
            return "Licencia activa en este equipo."
        if self.has_key:
            return "Hay una clave guardada, pero no se pudo validar (sin conexión reciente o clave inválida)."
        if self.trial_days_remaining > 0:
            return f"Prueba gratuita: {self.trial_days_remaining} día(s) restante(s)."
        return "Tu prueba gratuita de 3 días finalizó. Activa una licencia para seguir usando GeoVial."


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    return datetime.fromisoformat(value)


def trial_days_remaining() -> int:
    state = license_store.load()
    if state.first_run_utc is None:
        state.first_run_utc = license_store.now_iso()
        license_store.save(state)

    first_run = _parse_iso(state.first_run_utc)
    elapsed_days = (datetime.now(timezone.utc) - first_run).days
    remaining = TRIAL_DAYS - elapsed_days
    return max(0, remaining)


def _fallback_to_cache(state: LicenseState) -> bool:
    if state.last_validated_utc is None:
        return False
    last_validated = _parse_iso(state.last_validated_utc)
    age_days = (datetime.now(timezone.utc) - last_validated).days
    if age_days > OFFLINE_GRACE_DAYS:
        return False
    return state.last_validation_result


def _validate(state: LicenseState) -> bool:
    try:
        resp = requests.post(
            f"{BACKEND_BASE_URL}/api/license/validate",
            json={"key": state.license_key, "machineId": hardware_id.get()},
            timeout=HTTP_TIMEOUT,
        )
        if not resp.ok:
            return _fallback_to_cache(state)

        valid = bool(resp.json().get("valid", False))
        state.last_validated_utc = license_store.now_iso()
        state.last_validation_result = valid
        license_store.save(state)
        return valid
    except requests.RequestException:
        return _fallback_to_cache(state)


def is_licensed() -> bool:
    state = license_store.load()
    if not state.license_key:
        return False
    return _validate(state)


def is_usable() -> bool:
    return trial_days_remaining() > 0 or is_licensed()


def get_status() -> LicenseStatus:
    state = license_store.load()
    trial_days = trial_days_remaining()
    has_key = bool(state.license_key)
    licensed = has_key and is_licensed()

    trial_end = None
    if state.first_run_utc:
        first_run = _parse_iso(state.first_run_utc)
        trial_end = (first_run + timedelta(days=TRIAL_DAYS)).astimezone()

    activated = None
    if state.activated_utc:
        activated = _parse_iso(state.activated_utc).astimezone()

    return LicenseStatus(
        trial_days_remaining=trial_days,
        has_key=has_key,
        licensed=licensed,
        license_key=state.license_key,
        hardware_id=hardware_id.get(),
        trial_end_date_local=trial_end,
        activated_date_local=activated,
    )


def activate(key: str) -> ActivationResult:
    key = (key or "").strip()
    if not key:
        return ActivationResult(False, "Introduce una clave de licencia.")

    try:
        resp = requests.post(
            f"{BACKEND_BASE_URL}/api/license/activate",
            json={"key": key, "machineId": hardware_id.get()},
            timeout=HTTP_TIMEOUT,
        )
    except requests.Timeout:
        return ActivationResult(
            False,
            "No se pudo contactar al servidor de licencias (tiempo de espera agotado). "
            "Verifica tu conexión e inténtalo de nuevo.",
        )
    except requests.RequestException as ex:
        return ActivationResult(
            False,
            f"No se pudo contactar al servidor de licencias. Verifica tu conexión e inténtalo de nuevo. ({ex})",
        )

    if resp.ok:
        licensed_to = resp.json().get("licensedTo", "")
        state = license_store.load()
        state.license_key = key
        state.last_validated_utc = license_store.now_iso()
        state.last_validation_result = True
        state.activated_utc = state.activated_utc or license_store.now_iso()
        license_store.save(state)
        return ActivationResult(
            True,
            f"Licencia activada correctamente para: {licensed_to}" if licensed_to
            else "Licencia activada correctamente.",
        )

    if resp.status_code == 404:
        return ActivationResult(False, "La clave de licencia no existe. Verifica que la copiaste correctamente.")
    if resp.status_code == 409:
        return ActivationResult(
            False,
            "Esta clave ya está activada en otro equipo. Cada licencia solo permite un dispositivo.",
        )

    # Para el resto de errores (ej. 402 "sin plan activo"), el backend manda
    # un mensaje ya listo para mostrar en el campo "error" del JSON.
    try:
        error_message = resp.json().get("error")
    except ValueError:
        error_message = None
    return ActivationResult(
        False,
        error_message or f"El servidor de licencias respondió con un error ({resp.status_code}).",
    )
