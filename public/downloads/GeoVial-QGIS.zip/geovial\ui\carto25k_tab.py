from qgis.core import QgsMapLayerProxyModel, QgsProject
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QFileDialog, QFormLayout, QGroupBox, QLabel, QLineEdit, QListWidget,
    QMessageBox, QPlainTextEdit, QPushButton, QVBoxLayout, QWidget,
)

from ..core import carto25k_tool
from .license_gate import ensure_usable


class Carto25kTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)

        note = QLabel(
            "Nota: la fusión final con relleno REST 1:100.000 de IGAC (para planchas que no se "
            "puedan descargar) todavía no está portada. La intersección con la Grilla 25k y la "
            "descarga automática por plancha sí funcionan."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #664d03; background-color: #fff3cd; padding: 6px; border-radius: 4px;")
        layout.addWidget(note)

        form_box = QGroupBox("Intersección con Grilla 25k")
        form = QFormLayout(form_box)
        self.input_combo = QgsMapLayerComboBox()
        form.addRow("Capa de entrada (AOI/eje):", self.input_combo)
        self.grilla_combo = QgsMapLayerComboBox()
        self.grilla_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Grilla 25k local:", self.grilla_combo)
        self.hoja_field_edit = QLineEdit()
        self.hoja_field_edit.setPlaceholderText("(autodetectar)")
        form.addRow("Campo de hoja:", self.hoja_field_edit)
        layout.addWidget(form_box)

        intersect_btn = QPushButton("Intersectar")
        intersect_btn.clicked.connect(self._on_intersect)
        layout.addWidget(intersect_btn)

        self.hojas_list = QListWidget()
        layout.addWidget(QLabel("Hojas encontradas:"))
        layout.addWidget(self.hojas_list)

        download_box = QGroupBox("Descarga automática (portal Colombia en Mapas)")
        download_layout = QVBoxLayout(download_box)
        login_btn = QPushButton("Iniciar sesión (una vez)…")
        login_btn.clicked.connect(self._on_login)
        download_layout.addWidget(login_btn)
        download_btn = QPushButton("Descargar planchas de la lista de arriba…")
        download_btn.clicked.connect(self._on_download_all)
        download_layout.addWidget(download_btn)
        self.download_log = QPlainTextEdit()
        self.download_log.setReadOnly(True)
        self.download_log.setMaximumBlockCount(500)
        download_layout.addWidget(self.download_log)
        layout.addWidget(download_box)

        gdb_box = QGroupBox("Listar capas de una GDB/GeoPackage descargado")
        gdb_layout = QVBoxLayout(gdb_box)
        pick_btn = QPushButton("Elegir carpeta .gdb o archivo .gpkg…")
        pick_btn.clicked.connect(self._on_pick_gdb)
        gdb_layout.addWidget(pick_btn)
        self.layers_list = QListWidget()
        gdb_layout.addWidget(self.layers_list)
        layout.addWidget(gdb_box)

        layout.addStretch(1)

    def _log(self, msg: str):
        self.download_log.appendPlainText(str(msg))
        self.download_log.repaint()

    def _check_playwright(self) -> bool:
        try:
            import playwright  # noqa: F401
        except ImportError:
            QMessageBox.critical(
                self, "GeoVial",
                "Falta el paquete 'playwright'. Instálalo una vez desde la consola Python de QGIS o "
                "una terminal OSGeo4W con:\n\n"
                "python -m pip install playwright\n"
                "python -m playwright install chromium",
            )
            return False
        return True

    def _on_intersect(self):
        if not ensure_usable(self):
            return
        input_layer = self.input_combo.currentLayer()
        grilla_layer = self.grilla_combo.currentLayer()
        if input_layer is None or grilla_layer is None:
            QMessageBox.warning(self, "GeoVial", "Selecciona la capa de entrada y la Grilla 25k.")
            return
        try:
            out_layer, hojas, hoja_field = carto25k_tool.intersect_grid(
                input_layer, grilla_layer, hoja_field=self.hoja_field_edit.text().strip() or None, log=print,
            )
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error: {ex}")
            return

        QgsProject.instance().addMapLayer(out_layer)
        self.hojas_list.clear()
        self.hojas_list.addItems(hojas)
        QMessageBox.information(
            self, "GeoVial",
            f"{len(hojas)} plancha(s) encontradas (campo: {hoja_field}). "
            "Capa de disponibilidad cargada al mapa.",
        )

    def _on_login(self):
        if not self._check_playwright():
            return
        QMessageBox.information(
            self, "GeoVial",
            "Se abrirá una ventana del navegador con el portal Colombia en Mapas. Inicia sesión "
            "(Google, correo, etc.) y luego CIERRA esa ventana para continuar. QGIS quedará "
            "congelado mientras tanto — es normal.",
        )
        from ..core import carto25k_browser
        try:
            carto25k_browser.login_interactive(log=self._log)
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error abriendo el navegador: {ex}")
            return
        QMessageBox.information(self, "GeoVial", "Sesión guardada. Ya puedes descargar planchas.")

    def _on_download_all(self):
        if not ensure_usable(self):
            return
        if not self._check_playwright():
            return
        hojas = [self.hojas_list.item(i).text() for i in range(self.hojas_list.count())]
        if not hojas:
            QMessageBox.warning(self, "GeoVial", "Primero intersecta con la Grilla 25k para obtener la lista de hojas.")
            return
        dest_folder = QFileDialog.getExistingDirectory(self, "Carpeta destino de las descargas")
        if not dest_folder:
            return

        from ..core import carto25k_browser
        self.download_log.clear()
        self._log(f"Descargando {len(hojas)} plancha(s) a {dest_folder}...")
        try:
            results = carto25k_browser.download_all(hojas, dest_folder, log=self._log)
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error durante la descarga: {ex}")
            return

        ok = [r for r in results if r.success]
        fail = [r for r in results if not r.success]
        self._log(f"\nRESUMEN: {len(ok)} OK, {len(fail)} con error.")
        for r in fail:
            self._log(f"  {r.hoja}: {r.error}")

        QMessageBox.information(
            self, "GeoVial",
            f"{len(ok)} plancha(s) descargadas correctamente, {len(fail)} con error "
            "(detalle en el registro de la pestaña).",
        )

    def _on_pick_gdb(self):
        path = QFileDialog.getExistingDirectory(self, "Elige la carpeta .gdb (o cancela para elegir un archivo)")
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, "Elige el archivo .gpkg/.mdb", filter="Geodatos (*.gpkg *.mdb)")
        if not path:
            return
        try:
            items = carto25k_tool.list_layers(path)
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error: {ex}")
            return
        self.layers_list.clear()
        self.layers_list.addItems([it["name"] for it in items])
