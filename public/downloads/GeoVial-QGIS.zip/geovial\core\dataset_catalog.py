"""Catálogo de datasets soportados (puerto de DatasetCatalog.cs).

Landsat/Sentinel-2 (ópticos) + DEM, con el proveedor, el nombre que exige
cada API y el mapeo de bandas para el cálculo de índices espectrales.
"""
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class Provider(Enum):
    USGS = "Usgs"
    CDSE = "Cdse"


class DatasetKind(Enum):
    OPTICAL = "Optical"
    DEM = "Dem"


class CloudMaskType(Enum):
    NONE = "None"
    SENTINEL_SCL = "SentinelScl"
    LANDSAT_QA = "LandsatQa"


@dataclass(frozen=True)
class BandMap:
    blue: str
    green: str
    red: str
    nir: str
    swir1: str
    swir2: str


@dataclass(frozen=True)
class DatasetInfo:
    display_name: str
    provider: Provider
    kind: DatasetKind
    dataset_name: Optional[str] = None       # USGS M2M datasetAlias
    cdse_collection: Optional[str] = None    # p.ej. "SENTINEL-2"
    cdse_product_type: Optional[str] = None  # p.ej. "S2MSI2A"
    bands: Optional[BandMap] = None
    cloud_mask: CloudMaskType = CloudMaskType.NONE
    cloud_mask_band: Optional[str] = None
    direct_tile_download: bool = False


LANDSAT_C2_L2 = DatasetInfo(
    display_name="Landsat 8/9 C2 L2 (USGS, 30 m)",
    provider=Provider.USGS,
    dataset_name="landsat_ot_c2_l2",
    kind=DatasetKind.OPTICAL,
    bands=BandMap(blue="SR_B2", green="SR_B3", red="SR_B4", nir="SR_B5", swir1="SR_B6", swir2="SR_B7"),
    cloud_mask=CloudMaskType.LANDSAT_QA,
    cloud_mask_band="QA_PIXEL",
)

SENTINEL2 = DatasetInfo(
    display_name="Sentinel-2 L2A (Copernicus, 10 m)",
    provider=Provider.CDSE,
    cdse_collection="SENTINEL-2",
    cdse_product_type="S2MSI2A",
    kind=DatasetKind.OPTICAL,
    bands=BandMap(blue="B02_10m", green="B03_10m", red="B04_10m", nir="B08_10m", swir1="B11_20m", swir2="B12_20m"),
    cloud_mask=CloudMaskType.SENTINEL_SCL,
    cloud_mask_band="SCL_20m",
)

SRTM1_ARC = DatasetInfo(
    display_name="SRTM 1 Arc-Second Global (USGS, 30 m)",
    provider=Provider.USGS,
    dataset_name="srtm_v3",
    kind=DatasetKind.DEM,
)

SRTM_VOID_FILLED = DatasetInfo(
    display_name="SRTM Void Filled (USGS, 30 m)",
    provider=Provider.USGS,
    dataset_name="srtm_v2",
    kind=DatasetKind.DEM,
)

COPERNICUS_DEM_30 = DatasetInfo(
    display_name="Copernicus DEM GLO-30 (TanDEM-X, 30 m)",
    provider=Provider.CDSE,
    dataset_name="copernicus_dem_glo30",
    kind=DatasetKind.DEM,
    direct_tile_download=True,
)

OPTICAL = [LANDSAT_C2_L2, SENTINEL2]
DEM = [COPERNICUS_DEM_30, SRTM1_ARC, SRTM_VOID_FILLED]


def infer_from_folder(folder: str) -> Optional[DatasetInfo]:
    import os
    if not folder:
        return None
    name = os.path.basename(folder.rstrip("\\/")).upper()
    if "MSIL2A" in name or "MSIL1C" in name or name.startswith("S2"):
        return SENTINEL2
    if "_L2SP" in name or "LC08" in name or "LC09" in name or name.startswith("LANDSAT"):
        return LANDSAT_C2_L2
    return None
