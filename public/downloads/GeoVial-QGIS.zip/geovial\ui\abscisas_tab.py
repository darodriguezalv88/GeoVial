from qgis.core import QgsMapLayerProxyModel, QgsProject
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QFormLayout, QGroupBox, QLineEdit, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from ..core import abscisas_tool
from .layer_rows import NamedLayerListWidget
from .license_gate import ensure_usable


class AbscisasTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)

        box = QGroupBox("Ejes")
        box_layout = QVBoxLayout(box)
        self.axes_widget = NamedLayerListWidget(QgsMapLayerProxyModel.LineLayer)
        box_layout.addWidget(self.axes_widget)
        layout.addWidget(box)

        form_box = QGroupBox("Puntos a numerar")
        form = QFormLayout(form_box)
        self.points_combo = QgsMapLayerComboBox()
        self.points_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        form.addRow("Capa de puntos:", self.points_combo)

        self.prefix_edit = QLineEdit("PTO")
        form.addRow("Prefijo:", self.prefix_edit)

        self.campo_filtro_edit = QLineEdit()
        self.campo_filtro_edit.setPlaceholderText("(opcional)")
        form.addRow("Campo filtro:", self.campo_filtro_edit)

        self.valor_filtro_edit = QLineEdit()
        self.valor_filtro_edit.setPlaceholderText("(opcional)")
        form.addRow("Valor filtro:", self.valor_filtro_edit)

        layout.addWidget(form_box)

        run_btn = QPushButton("Calcular abscisas")
        run_btn.clicked.connect(self._on_run)
        layout.addWidget(run_btn)
        layout.addStretch(1)

    def _on_run(self):
        if not ensure_usable(self):
            return
        axes = self.axes_widget.values()
        points_layer = self.points_combo.currentLayer()
        if not axes:
            QMessageBox.warning(self, "GeoVial", "Agrega al menos un eje.")
            return
        if points_layer is None:
            QMessageBox.warning(self, "GeoVial", "Selecciona la capa de puntos.")
            return
        try:
            n = abscisas_tool.run(
                axes, points_layer,
                prefix=self.prefix_edit.text().strip() or "PTO",
                campo_filtro=self.campo_filtro_edit.text().strip() or None,
                valor_filtro=self.valor_filtro_edit.text().strip() or None,
                log=print,
            )
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error: {ex}")
            return
        points_layer.triggerRepaint()
        QMessageBox.information(self, "GeoVial", f"{n} punto(s) actualizados con NOMBRE/Abscisa_m/Abscisa_txt/OBS.")
