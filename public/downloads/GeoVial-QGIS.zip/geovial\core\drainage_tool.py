"""Obras de drenaje transversal — puerto de DrainageService.cs +
obras_drenaje_transversal.py.

Para cada alternativa: bufferiza el eje (corredor), lo intersecta con la red
de drenaje permanente (filtrada por campo/valor) y genera una obra por cada
cruce real, con abscisa y numeración ODT_001, ODT_002...
"""
from collections import defaultdict
from typing import Dict

from qgis.core import QgsVectorLayer
from qgis.PyQt.QtCore import QVariant
from shapely.geometry import Point

from . import geom_common as gc

_OUT_FIELDS = [
    ("ALTERNATIVA", QVariant.String, 20),
    ("NUM_ODT", QVariant.String, 10),
    ("NOMBRE_GEOGRAFICO", QVariant.String, 100),
    ("FID_Drenaje", QVariant.LongLong, 0),
    ("Longitud_Obra", QVariant.Double, 0),
    ("Abscisa_m", QVariant.Double, 0),
    ("Abscisa_txt", QVariant.String, 12),
    ("NOTA", QVariant.String, 40),
]


def run(
    axes: Dict[str, QgsVectorLayer],
    drainage_layer: QgsVectorLayer,
    campo: str = "ESTADO_DRENAJE",
    valor=5101,
    buffer_m: float = 25,
    log=print,
):
    crs = drainage_layer.crs()

    where = gc.build_where(drainage_layer, campo, valor)
    perm = gc.read_features(drainage_layer, where=where)
    log(f"PASO 1: cauces permanentes ({where}): {len(perm)}")
    if not perm:
        raise ValueError("0 cauces permanentes con ese filtro. Revisa campo/valor.")

    axis_geoms = {name: gc.load_axis_geom(layer) for name, layer in axes.items()}

    log(f"PASO 2: buffers de {buffer_m} m por alternativa...")
    corridors = {}
    for name, layer in axes.items():
        corridors[name] = gc.buffer_dissolved(layer, buffer_m)

    log("PASO 3: intersectando corredores con drenaje permanente...")
    obras = {}  # (alt, idx) -> dict
    for alt, corridor in corridors.items():
        seg_i = 0
        for feat in perm:
            inter = feat["geom"].intersection(corridor)
            for seg in gc.explode_lines(inter):
                fp = seg.coords[0]
                lp = seg.coords[-1]
                obras[(alt, seg_i)] = {
                    "fp": fp, "lp": lp, "lon": round(gc.dist2(fp, lp), 3),
                    "fid_dr": feat["fid"],
                    "nom": feat["attrs"].get("NOMBRE_GEOGRAFICO") or "",
                    "pt_eje": None, "tiene_eje": False,
                }
                seg_i += 1
        log(f"  {alt}: {seg_i} segmentos (= obras)")

    log("PASO 4: puntos del eje por cruce...")
    for alt, axis_layer in axes.items():
        eje_g = axis_geoms[alt]
        eje_lines = eje_g if isinstance(eje_g, list) else [eje_g]
        for (a, idx), obra in obras.items():
            if a != alt:
                continue
            from shapely.geometry import LineString
            seg_line = LineString([obra["fp"], obra["lp"]])
            for eje_line in eje_lines:
                inter = eje_line.intersection(seg_line)
                if inter.is_empty:
                    continue
                pt = inter.geoms[0] if hasattr(inter, "geoms") else inter
                if pt.geom_type == "Point":
                    obra["pt_eje"] = (pt.x, pt.y)
                    obra["tiene_eje"] = True
                    break

    con = sum(1 for o in obras.values() if o["tiene_eje"])
    log(f"  Total obras: {len(obras)} | con cruce de eje: {con} | solo corredor: {len(obras) - con}")

    for (alt, idx), o in obras.items():
        eje_g = axis_geoms.get(alt)
        if eje_g:
            if o["tiene_eje"]:
                px, py = o["pt_eje"]
            else:
                px = (o["fp"][0] + o["lp"][0]) / 2
                py = (o["fp"][1] + o["lp"][1]) / 2
            o["absc"] = gc.measure_abscissa(Point(px, py), eje_g)
        else:
            o["absc"] = 0.0

    by_alt = defaultdict(list)
    for k in obras:
        by_alt[k[0]].append(k)
    ordered = []
    for alt in sorted(by_alt):
        keys_sorted = sorted(by_alt[alt], key=lambda k: obras[k]["absc"])
        for i, k in enumerate(keys_sorted):
            obras[k]["num_odt"] = f"ODT_{i + 1:03d}"
            obras[k]["absc_txt"] = gc.format_abscissa(obras[k]["absc"])
            ordered.append(k)

    points_layer = gc.make_memory_layer("Point", crs, "Cruces_Drenaje_Final", _OUT_FIELDS)
    lines_layer = gc.make_memory_layer("LineString", crs, "Longitud_Obra_Final", _OUT_FIELDS)

    for k in ordered:
        alt = k[0]
        o = obras[k]
        if o["tiene_eje"]:
            xy, nota = o["pt_eje"], "Eje_cruza_drenaje"
        else:
            xy = ((o["fp"][0] + o["lp"][0]) / 2, (o["fp"][1] + o["lp"][1]) / 2)
            nota = "Solo_en_corredor_revisar"
        attrs = [alt, o["num_odt"], o["nom"], o["fid_dr"], o["lon"], o["absc"], o["absc_txt"], nota]
        gc.add_feature(points_layer, Point(xy), attrs)

        from shapely.geometry import LineString
        gc.add_feature(lines_layer, LineString([o["fp"], o["lp"]]), attrs)

    log(f"PASO 5: {points_layer.featureCount()} puntos, {lines_layer.featureCount()} líneas.")

    stats = defaultdict(list)
    for k in ordered:
        stats[k[0]].append(obras[k]["lon"])
    for alt in sorted(stats):
        v = stats[alt]
        log(f"  {alt}: {len(v)} obras | total={sum(v):.1f} m | prom={sum(v) / len(v):.1f} m")

    buffer_layers = {}
    for name, corridor in corridors.items():
        buf_layer = gc.make_memory_layer("Polygon", crs, f"Buffer_{name}_{buffer_m}m", [])
        for poly in gc.explode_polygons(corridor):
            gc.add_feature(buf_layer, poly, [])
        buffer_layers[name] = buf_layer

    return points_layer, lines_layer, buffer_layers
