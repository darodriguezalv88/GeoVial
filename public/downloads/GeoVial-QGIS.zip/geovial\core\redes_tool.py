"""Obras sobre redes existentes (HS/HC) — puerto de RedesService.cs +
obras_redes_existentes.py.

Para cada alternativa x sector (p.ej. HS=alcantarillado sanitario,
HC=alcantarillado combinado/pluvial): bufferiza el eje, intersecta el
corredor con las capas de red de ese sector (opcionalmente filtradas) y
genera un segmento por tramo dentro del corredor + un punto de cruce real
donde el eje efectivamente atraviesa la red.
"""
from collections import defaultdict
from typing import Dict, List, Optional

from qgis.core import QgsVectorLayer
from qgis.PyQt.QtCore import QVariant
from shapely.geometry import LineString, Point

from . import geom_common as gc

_OUT_FIELDS = [
    ("TIPO_RED", QVariant.String, 10),
    ("ALTERNATIVA", QVariant.String, 20),
    ("NUM_CRUCE", QVariant.LongLong, 0),
    ("NOM_CRUCE", QVariant.String, 12),
    ("NOMBRE", QVariant.String, 200),
    ("Longitud_Red", QVariant.Double, 0),
    ("NOTA", QVariant.String, 40),
    ("OID_Fuente", QVariant.LongLong, 0),
    ("Abscisa_m", QVariant.Double, 0),
    ("Abscisa_txt", QVariant.String, 12),
]

_NOMBRE_FIELDS = {"HS": "NOMBRE", "HC": "nomenclat"}


class RedLayerSpec:
    def __init__(self, layer: QgsVectorLayer, campo_filtro: Optional[str] = None, valor_filtro=None):
        self.layer = layer
        self.campo_filtro = campo_filtro
        self.valor_filtro = valor_filtro


def _collect_sector_features(target_crs, capas: List[RedLayerSpec], sector: str, log):
    """Junta las features (ya filtradas por capa) de todas las capas de un
    sector, reproyectadas al CRS de referencia."""
    out = []
    for spec in capas:
        where = None
        if spec.campo_filtro and spec.valor_filtro not in (None, ""):
            if spec.layer.fields().indexOf(spec.campo_filtro) < 0:
                log(f"  AVISO: campo '{spec.campo_filtro}' no existe en {spec.layer.name()} — se procesa sin filtro")
            else:
                where = gc.build_where(spec.layer, spec.campo_filtro, spec.valor_filtro)
        feats = gc.read_features_in_crs(spec.layer, target_crs, where=where)
        if where and not feats:
            log(f"  AVISO: ningún feature coincide con el filtro en {spec.layer.name()} — se omite capa")
            continue
        nom_field = _NOMBRE_FIELDS.get(sector, "")
        nom_key = next((k for k in (feats[0]["attrs"].keys() if feats else []) if nom_field.upper() in k.upper()), None)
        for f in feats:
            out.append({"fid": f["fid"], "geom": f["geom"], "nombre": f["attrs"].get(nom_key, "") if nom_key else ""})
        log(f"  {spec.layer.name()}: {len(feats)} tramos" + (f" (filtro: {where})" if where else ""))
    return out


def run(
    axes: Dict[str, QgsVectorLayer],
    redes: Dict[str, List[RedLayerSpec]],
    buffer_m: float = 25,
    log=print,
):
    first_axis = next(iter(axes.values()))
    target_crs = first_axis.crs()

    log(f"PASO 1: buffers de {buffer_m} m para cada alternativa...")
    corridors = {name: gc.buffer_dissolved(layer, buffer_m) for name, layer in axes.items()}

    log("PASO 2: preparando redes por sector...")
    sector_feats = {}
    for sector, capas in redes.items():
        if not capas:
            continue
        feats = _collect_sector_features(target_crs, capas, sector, log)
        if not feats:
            log(f"  AVISO: {sector} sin capas válidas tras aplicar filtros — sector omitido")
            continue
        sector_feats[sector] = feats
        log(f"  {sector}: {len(feats)} tramos en total")

    axis_geoms = {name: gc.load_axis_geom(layer) for name, layer in axes.items()}
    axis_lines = {name: [f["geom"] for f in gc.read_features(layer)] for name, layer in axes.items()}

    log("PASO 3: intersectando corredores con redes...")
    # segs[(alt, sector)] = [ {geom, oid_fuente, nombre} ]
    segs = {}
    for alt, corridor in corridors.items():
        for sector, feats in sector_feats.items():
            seg_list = []
            for feat in feats:
                inter = feat["geom"].intersection(corridor)
                for part in gc.explode_lines(inter):
                    seg_list.append({"geom": part, "oid_fuente": feat["fid"], "nombre": feat["nombre"]})
            segs[(alt, sector)] = seg_list
            log(f"  {alt} x {sector}: {len(seg_list)} segmentos")

    log("PASO 4: puntos de cruce eje x red...")
    cross_points = {}  # (alt, sector, seg_index) -> (x, y)
    for alt, lines in axis_lines.items():
        for sector in sector_feats:
            seg_list = segs.get((alt, sector), [])
            for i, seg in enumerate(seg_list):
                seg_line = seg["geom"]
                for eje_line in lines:
                    inter = eje_line.intersection(seg_line)
                    if inter.is_empty:
                        continue
                    pt = inter.geoms[0] if hasattr(inter, "geoms") else inter
                    if pt.geom_type == "Point":
                        cross_points[(alt, sector, i)] = (pt.x, pt.y)
                        break
            n_cross = sum(1 for k in cross_points if k[0] == alt and k[1] == sector)
            log(f"  {alt} x {sector}: {n_cross} puntos de cruce")

    log("PASO 5: calculando atributos y abscisas...")
    all_segments = []  # dicts listos para escribir, con NUM_CRUCE ya asignado
    for (alt, sector), seg_list in segs.items():
        eje_g = axis_geoms.get(alt)
        abscisas = {}
        for i, seg in enumerate(seg_list):
            xy = cross_points.get((alt, sector, i))
            if xy and eje_g:
                absc = gc.measure_abscissa(Point(*xy), eje_g)
            elif eje_g:
                c = seg["geom"].centroid
                absc = gc.measure_abscissa(Point(c.x, c.y), eje_g)
            else:
                absc = 0.0
            abscisas[i] = absc

        sorted_idx = sorted(abscisas, key=lambda i: abscisas[i])
        idx_to_num = {i: n + 1 for n, i in enumerate(sorted_idx)}

        for i, seg in enumerate(seg_list):
            num = idx_to_num[i]
            absc = abscisas[i]
            nota = "Eje_cruza_red" if (alt, sector, i) in cross_points else "Solo_en_corredor_revisar"
            all_segments.append({
                "tipo_red": sector, "alternativa": alt, "num_cruce": num,
                "nom_cruce": f"{sector}_{num:03d}", "nombre": seg["nombre"],
                "longitud": seg["geom"].length, "nota": nota,
                "oid_fuente": seg["oid_fuente"], "abscisa": absc,
                "abscisa_txt": gc.format_abscissa(absc), "geom": seg["geom"],
            })
        log(f"  {alt} x {sector}: {len(seg_list)} tramos atribuidos")

    lines_layer = gc.make_memory_layer("LineString", target_crs, "Longitud_Redes_Final", _OUT_FIELDS)
    points_layer = gc.make_memory_layer("Point", target_crs, "Cruces_Redes_Final", _OUT_FIELDS)

    for s in all_segments:
        attrs = [s["tipo_red"], s["alternativa"], s["num_cruce"], s["nom_cruce"], s["nombre"],
                 s["longitud"], s["nota"], s["oid_fuente"], s["abscisa"], s["abscisa_txt"]]
        gc.add_feature(lines_layer, s["geom"], attrs)
        if s["nota"] == "Eje_cruza_red":
            key = (s["alternativa"], s["tipo_red"])
            idx = next(i for i, seg in enumerate(segs.get(key, [])) if seg["geom"].equals(s["geom"]))
            xy = cross_points.get((s["alternativa"], s["tipo_red"], idx))
            pt = Point(*xy) if xy else s["geom"].centroid
        else:
            pt = s["geom"].centroid
        gc.add_feature(points_layer, pt, attrs)

    log(f"{lines_layer.featureCount()} tramos de red, {points_layer.featureCount()} puntos de cruce.")

    stats = defaultdict(lambda: defaultdict(list))
    for s in all_segments:
        stats[s["alternativa"]][s["tipo_red"]].append(s["longitud"])
    for alt in sorted(stats):
        for sec in sorted(stats[alt]):
            v = stats[alt][sec]
            log(f"  {alt} - {sec}: {len(v)} tramos | total={sum(v):.1f} m | prom={sum(v) / len(v):.1f} m")

    return points_layer, lines_layer
