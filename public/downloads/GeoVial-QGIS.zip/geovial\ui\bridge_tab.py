from qgis.core import QgsMapLayerProxyModel, QgsProject
from qgis.PyQt.QtWidgets import (
    QDoubleSpinBox, QFormLayout, QGroupBox, QLineEdit, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from ..core import bridge_tool
from .layer_rows import FilterableLayerListWidget, NamedLayerListWidget
from .license_gate import ensure_usable


class BridgeTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)

        box = QGroupBox("Ejes / alternativas")
        box_layout = QVBoxLayout(box)
        self.axes_widget = NamedLayerListWidget(QgsMapLayerProxyModel.LineLayer)
        box_layout.addWidget(self.axes_widget)
        layout.addWidget(box)

        drenaje_box = QGroupBox("Drenaje doble (polígonos de cuerpos de agua)")
        drenaje_layout = QVBoxLayout(drenaje_box)
        self.drenajes_widget = FilterableLayerListWidget(QgsMapLayerProxyModel.PolygonLayer)
        drenaje_layout.addWidget(self.drenajes_widget)
        layout.addWidget(drenaje_box)

        form_box = QGroupBox("Parámetros")
        form = QFormLayout(form_box)
        self.campo_nombre_edit = QLineEdit("NOMBRE_GEOGRAFICO")
        form.addRow("Campo de nombre:", self.campo_nombre_edit)
        self.tol_spin = QDoubleSpinBox()
        self.tol_spin.setRange(0, 100)
        self.tol_spin.setValue(0.5)
        self.tol_spin.setSuffix(" m")
        form.addRow("Tolerancia de nombre:", self.tol_spin)
        layout.addWidget(form_box)

        run_btn = QPushButton("Calcular puentes")
        run_btn.clicked.connect(self._on_run)
        layout.addWidget(run_btn)
        layout.addStretch(1)

    def _on_run(self):
        if not ensure_usable(self):
            return
        axes = self.axes_widget.values()
        drenajes = [layer for layer, _campo, _valor in self.drenajes_widget.values()]
        if not axes:
            QMessageBox.warning(self, "GeoVial", "Agrega al menos un eje.")
            return
        if not drenajes:
            QMessageBox.warning(self, "GeoVial", "Agrega al menos una capa de drenaje doble.")
            return
        try:
            points_layer, lines_layer = bridge_tool.run(
                axes, drenajes,
                campo_nombre=self.campo_nombre_edit.text().strip() or None,
                tol_nombre_m=self.tol_spin.value(),
                log=print,
            )
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error: {ex}")
            return

        project = QgsProject.instance()
        project.addMapLayer(lines_layer)
        project.addMapLayer(points_layer)
        QMessageBox.information(self, "GeoVial", f"{points_layer.featureCount()} puente(s) calculados y cargados al mapa.")
