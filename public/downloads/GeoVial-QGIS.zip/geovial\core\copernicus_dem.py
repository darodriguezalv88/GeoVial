"""Descarga de teselas Copernicus DEM GLO-30 desde el bucket público de AWS.

Puerto de CopernicusDemService.cs. Sin login ni API de búsqueda: cada tesela
cubre 1°x1° y se nombra por su esquina inferior-izquierda (SW).
"""
import math
from typing import Callable, List, Optional

from . import download_service

_BASE_URL = "https://copernicus-dem-30m.s3.amazonaws.com"


def tile_urls(min_lon: float, min_lat: float, max_lon: float, max_lat: float) -> List[str]:
    urls = []
    lat0, lat1 = math.floor(min_lat), math.floor(max_lat)
    lon0, lon1 = math.floor(min_lon), math.floor(max_lon)
    for lat in range(int(lat0), int(lat1) + 1):
        for lon in range(int(lon0), int(lon1) + 1):
            ns = "N" if lat >= 0 else "S"
            ew = "E" if lon >= 0 else "W"
            name = f"Copernicus_DSM_COG_10_{ns}{abs(lat):02d}_00_{ew}{abs(lon):03d}_00_DEM"
            urls.append(f"{_BASE_URL}/{name}/{name}.tif")
    return urls


def download(
    dest_folder: str,
    min_lon: float, min_lat: float, max_lon: float, max_lat: float,
    on_status: Optional[Callable[[str], None]] = None,
) -> List[str]:
    files = []
    urls = tile_urls(min_lon, min_lat, max_lon, max_lat)
    for i, url in enumerate(urls, start=1):
        if on_status:
            on_status(f"Tesela DEM {i}/{len(urls)}…")
        try:
            files.append(download_service.download_file(url, dest_folder))
        except Exception:
            # Tesela inexistente (océano) u otro error puntual: se omite.
            pass
    return files
