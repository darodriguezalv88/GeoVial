"""Modelos de datos compartidos (puerto de SceneResult/SearchCriteria/DownloadItem)."""
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional

from .dataset_catalog import DatasetInfo, Provider


@dataclass
class SearchCriteria:
    dataset: DatasetInfo
    min_lon: float
    min_lat: float
    max_lon: float
    max_lat: float
    start_date: datetime = field(default_factory=lambda: datetime.now(timezone.utc) - timedelta(days=90))
    end_date: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    min_cloud: int = 0
    max_cloud: int = 30
    max_results: int = 50

    def validate(self) -> Optional[str]:
        if self.dataset is None:
            return "Selecciona un producto."
        if self.max_lon <= self.min_lon or self.max_lat <= self.min_lat:
            return "La extensión no es válida."
        if self.end_date < self.start_date:
            return "La fecha final es anterior a la inicial."
        return None


@dataclass
class SceneResult:
    entity_id: str
    display_id: str
    dataset_name: str
    acquisition_date: datetime
    cloud_cover: float
    browse_url: Optional[str] = None
    footprint_geojson: Optional[str] = None
    provider: Provider = Provider.USGS

    @property
    def summary(self) -> str:
        return f"{self.acquisition_date:%Y-%m-%d}  ·  Nubes: {self.cloud_cover:.0f}%  ·  {self.display_id}"


@dataclass
class DownloadItem:
    entity_id: Optional[str] = None
    product_id: Optional[str] = None
    product_name: Optional[str] = None
    file_size: int = 0
    available: bool = False
    url: Optional[str] = None
