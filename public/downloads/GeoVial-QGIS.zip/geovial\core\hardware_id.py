"""Identificador estable de máquina para el machine-binding de licencias.

Mismo esquema que HardwareId.cs del add-in de ArcGIS Pro: MachineGuid del
registro, hasheado con SHA-256 y la misma sal ("SatImageryAddin::GeoVial::").
Usar la MISMA sal es intencional: si el usuario instala el add-in de Pro y
el plugin de QGIS en el mismo equipo, ambos calculan el mismo machineId y el
backend los cuenta como un solo dispositivo (no dos activaciones).
"""
import hashlib
import platform
import winreg

_cached = None


def get() -> str:
    global _cached
    if _cached is not None:
        return _cached

    raw = _machine_guid() or platform.node()
    _cached = _hash(raw)
    return _cached


def _machine_guid():
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
            return value or None
    except OSError:
        return None


def _hash(raw: str) -> str:
    data = ("SatImageryAddin::GeoVial::" + raw).encode("utf-8")
    return hashlib.sha256(data).hexdigest()
