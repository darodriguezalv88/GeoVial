"""Carto 25k — puerto PARCIAL de Carto25kService.cs + carto25k_*.py.

Portado en esta pasada: intersección con la Grilla 25k (autodetección de
campo de hoja) y listado de feature classes de una geodatabase/GeoPackage ya
descargados.

NO portado todavía (queda para una iteración aparte, fuera del alcance de
esta ronda): la descarga automática por plancha contra el portal "Colombia
en Mapas" (que en el add-in de ArcGIS Pro usa un navegador embebido,
Carto25kBrowserService) y la fusión final con relleno de huecos desde el
servicio REST 1:100.000 de IGAC. El flujo manual mientras tanto: usa la
lista de hojas + la capa de disponibilidad que esta herramienta genera para
saber qué planchas bajar a mano del portal, cárgalas en QGIS y fusiónalas
con las herramientas nativas (Vectorial > Herramientas de gestión de datos >
Combinar).
"""
import os
from typing import List, Optional, Tuple

from osgeo import ogr
from qgis.core import QgsVectorLayer, QgsWkbTypes
from qgis.PyQt.QtCore import QVariant

from . import geom_common as gc

_GEOM_TYPE_NAME = {
    QgsWkbTypes.PointGeometry: "Point",
    QgsWkbTypes.LineGeometry: "LineString",
    QgsWkbTypes.PolygonGeometry: "Polygon",
}

_SINGLE_CANDIDATES = ["HOJA", "NUM_HOJA", "HOJA_NUM", "NUMERO_HOJA", "HOJA_CODE", "CODIGO_HOJA", "MAPA"]
_COD_CANDIDATES = ["COD_PL", "CODIGO_PLANCHA", "COD_PLANCHA", "NUM_PLANCHA"]
_ROMANO_CANDIDATES = ["ROMANO"]
_LETRA_CANDIDATES = ["LETRA"]


def _find_field(names, candidatos):
    upper = {n.upper(): n for n in names}
    for c in candidatos:
        if c in upper:
            return upper[c]
    for c in candidatos:
        for n in names:
            if c in n.upper():
                return n
    return None


def _fmt_part(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v).strip()


def intersect_grid(
    input_layer: QgsVectorLayer,
    grilla_layer: QgsVectorLayer,
    hoja_field: Optional[str] = None,
    log=print,
) -> Tuple[QgsVectorLayer, List[str], str]:
    names = [f.name() for f in grilla_layer.fields()]
    cod_field = romano_field = letra_field = None
    hoja_field = (hoja_field or "").strip() or None

    if not hoja_field:
        hoja_field = _find_field(names, _SINGLE_CANDIDATES)
    if not hoja_field:
        cod_field = _find_field(names, _COD_CANDIDATES)
        romano_field = _find_field(names, _ROMANO_CANDIDATES)
        letra_field = _find_field(names, _LETRA_CANDIDATES)
        if not (cod_field and romano_field and letra_field):
            raise ValueError(
                "No se pudo autodetectar el código de hoja en la Grilla 25k "
                "(ni un campo único HOJA/PLANCHA, ni COD_PL+ROMANO+LETRA). Indica 'hoja_field' explícitamente."
            )
        log(f"Código de hoja compuesto a partir de: {cod_field} + {romano_field} + {letra_field}")
    else:
        log(f"Campo de número de hoja: {hoja_field}")

    log("Seleccionando planchas que intersectan la capa de entrada...")
    from shapely.ops import unary_union
    input_geoms = [f["geom"] for f in gc.read_features_in_crs(input_layer, grilla_layer.crs())]
    input_union = unary_union(input_geoms)

    needs_hoja_code = cod_field is not None  # split fields -> se calcula un HOJA_CODE nuevo
    if needs_hoja_code:
        hoja_field = "HOJA_CODE"

    grid_fields = [(n, grilla_layer.fields().field(n).type()) for n in names]
    extra_fields = [("DISPONIBLE", QVariant.String, 5), ("FUENTE", QVariant.String, 20),
                    ("ANIO_ORIGEN", QVariant.String, 10), ("FORMATO", QVariant.String, 10)]
    if needs_hoja_code:
        extra_fields.append(("HOJA_CODE", QVariant.String, 20))

    out_fields = [(n, t, 0) for n, t in grid_fields] + extra_fields
    geom_name = _GEOM_TYPE_NAME.get(grilla_layer.geometryType(), "Polygon")
    out_layer = gc.make_memory_layer(geom_name, grilla_layer.crs(), "Carto25k_Grilla_Disponibilidad", out_fields)

    selected = [f for f in gc.read_features(grilla_layer) if f["geom"].intersects(input_union)]
    log(f"Planchas seleccionadas: {len(selected)}")
    if not selected:
        raise ValueError("La capa de entrada no intersecta ninguna plancha de la Grilla 25k.")

    hojas = set()
    for f in selected:
        attrs = f["attrs"]
        if needs_hoja_code:
            code = (_fmt_part(attrs.get(cod_field)) + _fmt_part(attrs.get(romano_field)) +
                    _fmt_part(attrs.get(letra_field))).upper()
        else:
            code = str(attrs.get(hoja_field) or "").strip().upper()
        if code:
            hojas.add(code)
        row = [attrs.get(n) for n, _t in grid_fields] + ["No", "", "", ""]
        if needs_hoja_code:
            row.append(code)
        gc.add_feature(out_layer, f["geom"], row)

    log(f"{len(hojas)} plancha(s) única(s) a procesar.")
    return out_layer, sorted(hojas), hoja_field


def list_layers(gdb_or_gpkg_path: str) -> List[dict]:
    """Lista las feature classes/capas de una GDB (OpenFileGDB) o GeoPackage.
    A diferencia de la versión arcpy (arcpy.da.Walk), no agrupa por feature
    dataset — OGR expone las capas de forma plana."""
    if not os.path.exists(gdb_or_gpkg_path):
        raise FileNotFoundError(f"No existe la ruta '{gdb_or_gpkg_path}'.")
    ds = ogr.Open(gdb_or_gpkg_path)
    if ds is None:
        raise RuntimeError(f"No se pudo abrir '{gdb_or_gpkg_path}' con GDAL/OGR.")
    items = []
    for i in range(ds.GetLayerCount()):
        layer = ds.GetLayerByIndex(i)
        items.append({"dataset": "", "name": layer.GetName()})
    ds = None
    return items
