"""Obras de puentes — puerto de BridgeService.cs + obras_puentes.py.

Une las capas de drenaje doble (polígonos de cuerpos de agua), disuelve
solapes/duplicados, intersecta cada eje con los cuerpos y genera un puente
por cada cruce real (punto medio + línea entrada-salida), recuperando el
nombre geográfico del cuerpo de agua original por ubicación.
"""
from collections import defaultdict
from typing import Dict, List, Optional

from qgis.core import QgsVectorLayer, QgsWkbTypes
from qgis.PyQt.QtCore import QVariant
from shapely.geometry import LineString, Point

from . import geom_common as gc

_OUT_FIELDS = [
    ("ALTERNATIVA", QVariant.String, 20),
    ("NUM_PUENTE", QVariant.String, 12),
    ("NOMBRE_GEOGRAFICO", QVariant.String, 100),
    ("FID_Drenaje", QVariant.LongLong, 0),
    ("Longitud_Puente", QVariant.Double, 0),
    ("Abscisa_m", QVariant.Double, 0),
    ("Abscisa_txt", QVariant.String, 12),
]


def run(
    axes: Dict[str, QgsVectorLayer],
    drenajes_doble: List[QgsVectorLayer],
    campo_nombre: Optional[str] = "NOMBRE_GEOGRAFICO",
    tol_nombre_m: float = 0.5,
    log=print,
):
    for d in drenajes_doble:
        if d.geometryType() != QgsWkbTypes.PolygonGeometry:
            raise ValueError(f"La capa '{d.name()}' no es de polígonos. Puentes requiere cuerpos de agua en polígono.")

    first_axis = next(iter(axes.values()))
    target_crs = first_axis.crs()

    log("PASO 0: uniendo capas de drenaje doble (polígonos)...")
    polys_orig = []  # {'fid','nom','area','geom'}
    for d in drenajes_doble:
        for feat in gc.read_features_in_crs(d, target_crs):
            nom = feat["attrs"].get(campo_nombre, "") if campo_nombre else ""
            polys_orig.append({"fid": feat["fid"], "nom": nom or "", "area": feat["geom"].area, "geom": feat["geom"]})
    log(f"  Cuerpos de agua unidos: {len(polys_orig)}")

    log("PASO 1: disolviendo cuerpos de agua (eliminar solapes/duplicados)...")
    dissolved = gc.dissolve_singlepart([p["geom"] for p in polys_orig])
    log(f"  {len(polys_orig)} -> {len(dissolved)} polígonos reales")

    def nombre_por_punto(px, py):
        pt = Point(px, py)
        cand = [p for p in polys_orig if p["geom"].contains(pt) or p["geom"].distance(pt) < tol_nombre_m]
        if not cand:
            return "", None
        con_nom = [c for c in cand if c["nom"].strip()]
        best = max(con_nom if con_nom else cand, key=lambda c: c["area"])
        return best["nom"], best["fid"]

    log("PASO 2: intersectando ejes con cuerpos de agua...")
    axis_geoms = {name: gc.load_axis_geom(layer) for name, layer in axes.items()}
    puentes = []
    for alt, axis_layer in axes.items():
        eje_lines = [feat["geom"] for feat in gc.read_features(axis_layer)]
        n_cruces = 0
        for eje_line in eje_lines:
            for poly in dissolved:
                inter = eje_line.intersection(poly)
                for seg in gc.explode_lines(inter):
                    fp, lp = seg.coords[0], seg.coords[-1]
                    cx, cy = (fp[0] + lp[0]) / 2, (fp[1] + lp[1]) / 2
                    nom, fid_dr = nombre_por_punto(cx, cy)
                    puentes.append({
                        "alt": alt, "fid_dr": fid_dr, "nom": nom,
                        "fp": fp, "lp": lp, "lon": round(gc.dist2(fp, lp), 3),
                        "mid": (cx, cy),
                    })
                    n_cruces += 1
        log(f"  {alt}: {n_cruces} cruces")

    for p in puentes:
        eje_g = axis_geoms.get(p["alt"])
        p["absc"] = gc.measure_abscissa(Point(*p["mid"]), eje_g) if eje_g else 0.0

    by_alt = defaultdict(list)
    for p in puentes:
        by_alt[p["alt"]].append(p)
    for alt in sorted(by_alt):
        grupo = sorted(by_alt[alt], key=lambda p: p["absc"])
        for i, p in enumerate(grupo):
            p["num_puente"] = f"PUENTE_{i + 1:03d}"
            p["absc_txt"] = gc.format_abscissa(p["absc"])

    log(f"  Total puentes: {len(puentes)}")

    crs = target_crs
    points_layer = gc.make_memory_layer("Point", crs, "Cruces_Drenaje_Puentes", _OUT_FIELDS)
    lines_layer = gc.make_memory_layer("LineString", crs, "Longitud_Puentes", _OUT_FIELDS)

    for alt in sorted(by_alt):
        for p in by_alt[alt]:
            attrs = [p["alt"], p["num_puente"], p["nom"], p["fid_dr"] if p["fid_dr"] is not None else -1,
                     p["lon"], p["absc"], p["absc_txt"]]
            gc.add_feature(points_layer, Point(*p["mid"]), attrs)
            gc.add_feature(lines_layer, LineString([p["fp"], p["lp"]]), attrs)

    log(f"{points_layer.featureCount()} puntos, {lines_layer.featureCount()} líneas.")
    return points_layer, lines_layer
