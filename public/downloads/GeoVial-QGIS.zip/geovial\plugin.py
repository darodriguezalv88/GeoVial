import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .ui.main_dock import GeoVialDock
from .ui.license_dialog import LicenseDialog


class GeoVialPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.action = None
        self.license_action = None

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)
        self.action = QAction(QIcon(os.path.join(plugin_dir, "icon.png")), "GeoVial", self.iface.mainWindow())
        self.action.triggered.connect(self.toggle_dock)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&GeoVial", self.action)

        self.license_action = QAction(
            QIcon(os.path.join(plugin_dir, "icon_license.png")), "Licencia GeoVial", self.iface.mainWindow()
        )
        self.license_action.triggered.connect(self.show_license_dialog)
        self.iface.addToolBarIcon(self.license_action)
        self.iface.addPluginToMenu("&GeoVial", self.license_action)

    def toggle_dock(self):
        if self.dock is None:
            self.dock = GeoVialDock(self.iface, self.iface.mainWindow())
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.setVisible(not self.dock.isVisible())

    def show_license_dialog(self):
        LicenseDialog(self.iface.mainWindow()).exec_()
        if self.dock is not None:
            self.dock._refresh_license_label()

    def unload(self):
        self.iface.removePluginMenu("&GeoVial", self.action)
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&GeoVial", self.license_action)
        self.iface.removeToolBarIcon(self.license_action)
        if self.dock is not None:
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
