def classFactory(iface):
    from .plugin import GeoVialPlugin
    return GeoVialPlugin(iface)
