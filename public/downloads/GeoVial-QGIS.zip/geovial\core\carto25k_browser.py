"""Descarga automática por plancha del portal "Colombia en Mapas" (IGAC).

Puerto funcional de Carto25kBrowserService.cs a Playwright (en vez de
WebView2/WPF, que no existe fuera de .NET). Mismo enfoque: automatiza un
navegador real contra el portal, porque no expone una API de descarga
directa. Requiere el paquete 'playwright' + su navegador Chromium
(`pip install playwright && playwright install chromium`), y que el usuario
inicie sesión una vez en el portal — la sesión se guarda en un perfil de
navegador persistente en disco y se reutiliza en las descargas siguientes.
"""
import os
import re
from dataclasses import dataclass
from typing import Callable, List, Optional

PORTAL_URL = "https://www.colombiaenmapas.gov.co/?u=0&t=23&servicio=5&cescala=1:25.000"
FORMAT_PRIORITY = ["GDB", "GPKG", "MDB", "SHP"]

_SET_SEARCH_JS = """
(hoja) => {
  const input = document.getElementById('searchCartoHoja');
  if (!input) return {ok: false, reason: 'no_input'};
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  setter.call(input, hoja);
  input.dispatchEvent(new Event('input', {bubbles: true}));
  input.dispatchEvent(new Event('change', {bubbles: true}));
  input.dispatchEvent(new KeyboardEvent('keyup', {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true}));
  return {ok: true};
}
"""

_FIND_BEST_JS = """
(hoja) => {
  const items = Array.from(document.querySelectorAll('#searchCartoList .media.media-resultados2'));
  let best = null, bestYear = -1;
  const vistos = [];
  items.forEach((it) => {
    const body = it.querySelector('.media-body');
    const text = body ? body.textContent.replace(/\\s+/g, ' ').trim() : '';
    const m = /Hoja\\s*([A-Za-z0-9\\-]+?)(?:Escala|$)/i.exec(text);
    const h = m ? m[1].trim().toUpperCase() : null;
    vistos.push(h || ('[sin match: ' + text.substring(0, 80) + ']'));
    if (!m || h !== hoja.toUpperCase()) return;
    const years = text.match(/\\d{4}/g);
    const year = years && years.length ? parseInt(years[years.length - 1], 10) : 0;
    if (year >= bestYear) { bestYear = year; best = it; }
  });
  if (!best) return {found: false, vistos: vistos};
  const titleEl = best.querySelector('.panel-resultados-titulo') || best;
  titleEl.click();
  return {found: true, anio: String(bestYear)};
}
"""

_SELECT_FORMAT_JS = """
(formato) => {
  const sel = document.getElementById('detalleCartoDescargaFormato');
  if (!sel) return {ok: false, reason: 'no_select'};
  const hasFormat = Array.from(sel.options).some((o) => o.value === formato);
  if (!hasFormat) return {ok: false, reason: 'no_format'};
  const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set;
  setter.call(sel, formato);
  sel.dispatchEvent(new Event('change', {bubbles: true}));
  const btn = document.querySelector('#detalleCartoDescarga .btn-primary.btn-interior');
  if (!btn) return {ok: false, reason: 'no_button'};
  btn.scrollIntoView({block: 'center', inline: 'center'});
  const r = btn.getBoundingClientRect();
  return {ok: true, x: r.left + r.width / 2, y: r.top + r.height / 2};
}
"""


def _profile_dir() -> str:
    path = os.path.join(os.environ["APPDATA"], "GeoVial", "Carto25kBrowserProfile")
    os.makedirs(path, exist_ok=True)
    return path


def _sanitize(name: str) -> str:
    return re.sub(r'[<>:"/\\|?*]', "_", name)


@dataclass
class DownloadOutcome:
    hoja: str
    success: bool = False
    file_path: Optional[str] = None
    formato: Optional[str] = None
    anio: Optional[str] = None
    error: Optional[str] = None


def login_interactive(log: Callable[[str], None] = print) -> None:
    """Abre el portal en una ventana visible para que el usuario inicie
    sesión (Google/correo/etc.). Bloquea hasta que el usuario CIERRA esa
    ventana — momento en el que la sesión ya quedó guardada en el perfil."""
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            _profile_dir(), headless=False, viewport={"width": 1400, "height": 900}
        )
        page = context.pages[0] if context.pages else context.new_page()
        page.goto(PORTAL_URL, wait_until="networkidle", timeout=60000)
        log("Inicia sesión en la ventana del portal y luego CIÉRRALA para continuar.")
        try:
            page.wait_for_event("close", timeout=0)
        except Exception:
            pass
        try:
            context.close()
        except Exception:
            pass


def _find_existing(hoja: str, dest_folder: str) -> Optional[str]:
    if not os.path.isdir(dest_folder):
        return None
    pattern = re.compile(rf"(^|[^A-Za-z0-9]){re.escape(hoja)}([^A-Za-z0-9]|$)", re.IGNORECASE)
    for name in os.listdir(dest_folder):
        if pattern.search(os.path.splitext(name)[0]):
            return os.path.join(dest_folder, name)
    return None


def download_hoja(numero_hoja: str, dest_folder: str, log: Callable[[str], None] = print) -> DownloadOutcome:
    from playwright.sync_api import TimeoutError as PWTimeout, sync_playwright

    os.makedirs(dest_folder, exist_ok=True)
    existente = _find_existing(numero_hoja, dest_folder)
    if existente:
        log(f"  {numero_hoja}: ya existe en la carpeta, se omite la descarga.")
        return DownloadOutcome(hoja=numero_hoja, success=True, file_path=existente, formato="(existente)")

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(_profile_dir(), headless=True)
        page = context.pages[0] if context.pages else context.new_page()
        try:
            page.goto(PORTAL_URL, wait_until="networkidle", timeout=60000)
            page.wait_for_timeout(1500)

            set_res = page.evaluate(_SET_SEARCH_JS, numero_hoja)
            if not set_res.get("ok"):
                return DownloadOutcome(hoja=numero_hoja, error="No se encontró el campo de búsqueda del portal.")
            page.wait_for_timeout(1500)

            best = page.evaluate(_FIND_BEST_JS, numero_hoja)
            if not best.get("found"):
                vistos = best.get("vistos", [])
                return DownloadOutcome(
                    hoja=numero_hoja,
                    error=f"No se encontró la hoja {numero_hoja} en el portal. Vistos: "
                          + (", ".join(vistos) if vistos else "(ninguno)"),
                )
            page.wait_for_timeout(1200)

            for formato in FORMAT_PRIORITY:
                sel = page.evaluate(_SELECT_FORMAT_JS, formato)
                if not sel.get("ok"):
                    continue
                log(f"  {numero_hoja}: intentando formato {formato}...")
                try:
                    with page.expect_download(timeout=45000) as dl_info:
                        page.mouse.move(sel["x"], sel["y"])
                        page.mouse.down()
                        page.mouse.up()
                    dl = dl_info.value
                    dest_path = os.path.join(dest_folder, _sanitize(dl.suggested_filename))
                    dl.save_as(dest_path)
                    log(f"  {numero_hoja}: OK ({formato}, {best.get('anio')}).")
                    return DownloadOutcome(
                        hoja=numero_hoja, success=True, file_path=dest_path,
                        formato=formato, anio=best.get("anio"),
                    )
                except PWTimeout:
                    continue

            if page.get_by_text("Iniciar sesión con Google").count() > 0:
                return DownloadOutcome(
                    hoja=numero_hoja,
                    error="No hay sesión activa en el portal — usa 'Iniciar sesión' y vuelve a intentar.",
                )
            return DownloadOutcome(
                hoja=numero_hoja,
                error="Ningún formato disponible o la descarga no arrancó en el tiempo esperado.",
            )
        finally:
            context.close()


def download_all(
    hojas: List[str], dest_folder: str, log: Callable[[str], None] = print
) -> List[DownloadOutcome]:
    results = []
    for i, hoja in enumerate(hojas, start=1):
        log(f"Descargando plancha {hoja} ({i}/{len(hojas)})...")
        try:
            results.append(download_hoja(hoja, dest_folder, log=log))
        except Exception as ex:
            results.append(DownloadOutcome(hoja=hoja, error=str(ex)))
    return results
