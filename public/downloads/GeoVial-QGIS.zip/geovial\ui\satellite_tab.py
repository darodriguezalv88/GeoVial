import os
import tempfile

from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
    QgsRasterLayer, QgsVectorLayer,
)
from qgis.PyQt.QtWidgets import (
    QComboBox, QDateEdit, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout,
    QLabel, QListWidget, QMessageBox, QPushButton, QSpinBox, QVBoxLayout, QWidget,
)

from ..core import (
    cdse_client, copernicus_dem, credential_store, dataset_catalog,
    download_service, processing_service, usgs_client,
)
from ..core.models import SearchCriteria
from .credentials_dialog import CredentialsDialog
from .license_gate import ensure_usable

_DATASETS = dataset_catalog.OPTICAL + dataset_catalog.DEM


class SatelliteTab(QWidget):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._scenes = []
        self._scene_folder = None
        self._current_dataset = None
        self._client = None

        layout = QVBoxLayout(self)

        search_box = QGroupBox("Buscar escenas")
        form = QFormLayout(search_box)

        self.dataset_combo = QComboBox()
        for ds in _DATASETS:
            self.dataset_combo.addItem(ds.display_name, ds)
        form.addRow("Dataset:", self.dataset_combo)

        extent_row = QHBoxLayout()
        self.extent_label = QLabel("(sin definir)")
        extent_btn = QPushButton("Usar extensión del lienzo")
        extent_btn.clicked.connect(self._grab_canvas_extent)
        extent_row.addWidget(self.extent_label, 1)
        extent_row.addWidget(extent_btn)
        form.addRow("Extensión:", extent_row)
        self._extent_4326 = None

        self.start_date = QDateEdit(calendarPopup=True)
        self.start_date.setDate(self.start_date.date().addMonths(-3))
        self.end_date = QDateEdit(calendarPopup=True)
        form.addRow("Desde:", self.start_date)
        form.addRow("Hasta:", self.end_date)

        self.cloud_spin = QSpinBox()
        self.cloud_spin.setRange(0, 100)
        self.cloud_spin.setValue(30)
        form.addRow("Nubosidad máx. (%):", self.cloud_spin)

        search_btn = QPushButton("Buscar")
        search_btn.clicked.connect(self._on_search)
        form.addRow(search_btn)

        layout.addWidget(search_box)

        results_box = QGroupBox("Resultados")
        results_layout = QVBoxLayout(results_box)
        self.results_list = QListWidget()
        results_layout.addWidget(self.results_list)
        download_btn = QPushButton("Descargar escena seleccionada")
        download_btn.clicked.connect(self._on_download)
        results_layout.addWidget(download_btn)
        layout.addWidget(results_box)

        proc_box = QGroupBox("Procesamiento")
        proc_layout = QVBoxLayout(proc_box)
        self.scene_folder_label = QLabel("Carpeta de escena: (ninguna)")
        self.scene_folder_label.setWordWrap(True)
        proc_layout.addWidget(self.scene_folder_label)

        index_row = QHBoxLayout()
        self.index_combo = QComboBox()
        for idx in processing_service.IndexType:
            self.index_combo.addItem(idx.value, idx)
        index_btn = QPushButton("Calcular índice")
        index_btn.clicked.connect(self._on_calculate_index)
        index_row.addWidget(self.index_combo, 1)
        index_row.addWidget(index_btn)
        proc_layout.addLayout(index_row)

        water_btn = QPushButton("Extraer cuerpos de agua")
        water_btn.clicked.connect(self._on_extract_water)
        proc_layout.addWidget(water_btn)

        layout.addWidget(proc_box)
        layout.addStretch(1)

    # ---- Extensión ----

    def _grab_canvas_extent(self):
        canvas = self.iface.mapCanvas()
        extent = canvas.extent()
        src_crs = canvas.mapSettings().destinationCrs()
        dst_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(src_crs, dst_crs, QgsProject.instance())
        transformed = transform.transformBoundingBox(extent)
        self._extent_4326 = (
            transformed.xMinimum(), transformed.yMinimum(),
            transformed.xMaximum(), transformed.yMaximum(),
        )
        self.extent_label.setText(
            "Lon [{:.4f}, {:.4f}]  Lat [{:.4f}, {:.4f}]".format(
                transformed.xMinimum(), transformed.xMaximum(),
                transformed.yMinimum(), transformed.yMaximum(),
            )
        )

    # ---- Búsqueda ----

    def _on_search(self):
        if not ensure_usable(self):
            return
        if self._extent_4326 is None:
            QMessageBox.warning(self, "GeoVial", "Define la extensión primero (usa el lienzo).")
            return

        dataset = self.dataset_combo.currentData()
        criteria = SearchCriteria(
            dataset=dataset,
            min_lon=self._extent_4326[0], min_lat=self._extent_4326[1],
            max_lon=self._extent_4326[2], max_lat=self._extent_4326[3],
            start_date=self.start_date.date().toPyDate(),
            end_date=self.end_date.date().toPyDate(),
            max_cloud=self.cloud_spin.value(),
        )
        error = criteria.validate()
        if error:
            QMessageBox.warning(self, "GeoVial", error)
            return

        try:
            client = self._ensure_client(dataset.provider)
            scenes = client.search_scenes(criteria)
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error en la búsqueda: {ex}")
            return

        self._scenes = scenes
        self._current_dataset = dataset
        self.results_list.clear()
        for scene in scenes:
            self.results_list.addItem(scene.summary)
        if not scenes:
            QMessageBox.information(self, "GeoVial", "No se encontraron escenas con esos criterios.")

    def _ensure_client(self, provider: dataset_catalog.Provider):
        saved = credential_store.try_load(provider)
        if not saved:
            dlg = CredentialsDialog(provider, self)
            if dlg.exec_() != dlg.Accepted:
                raise RuntimeError("Se requieren credenciales para continuar.")
            dlg.save()
            saved = dlg.values()

        user, secret = saved
        if provider == dataset_catalog.Provider.CDSE:
            client = cdse_client.CdseClient()
            client.login(user, secret)
        else:
            client = usgs_client.UsgsM2mClient()
            client.login(user, secret)
        return client

    # ---- Descarga ----

    def _on_download(self):
        row = self.results_list.currentRow()
        if row < 0 or row >= len(self._scenes):
            QMessageBox.warning(self, "GeoVial", "Selecciona una escena de la lista.")
            return
        scene = self._scenes[row]
        dataset = self._current_dataset

        dest_root = QFileDialog.getExistingDirectory(self, "Carpeta destino de la descarga")
        if not dest_root:
            return
        dest_folder = os.path.join(dest_root, scene.display_id or scene.entity_id)

        try:
            if dataset.direct_tile_download:
                files = copernicus_dem.download(dest_folder, *self._extent_4326)
                if not files:
                    raise RuntimeError("No se descargó ninguna tesela (¿bbox sobre el océano?).")
                self._scene_folder = dest_folder
            elif dataset.provider == dataset_catalog.Provider.CDSE:
                archive = self._client_for(dataset.provider).download_product(
                    scene.entity_id, scene.display_id, dest_folder
                )
                self._scene_folder = download_service.extract_archive(archive, dest_folder)
            else:
                client = self._client_for(dataset.provider)
                options = client.get_download_options(dataset.dataset_name, [scene.entity_id])
                available = [o for o in options if o.available] or options
                ready = client.request_downloads(available)
                if not ready:
                    raise RuntimeError("USGS aún está preparando la descarga; intenta de nuevo en unos minutos.")
                archive = download_service.download_file(ready[0].url, dest_folder)
                self._scene_folder = download_service.extract_archive(archive, dest_folder)
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error al descargar: {ex}")
            return

        self.scene_folder_label.setText(f"Carpeta de escena: {self._scene_folder}")
        QMessageBox.information(self, "GeoVial", "Descarga completa.")

    def _client_for(self, provider):
        if self._client is not None and getattr(self._client, "_provider_hint", None) == provider:
            return self._client
        client = self._ensure_client(provider)
        client._provider_hint = provider
        self._client = client
        return client

    # ---- Procesamiento ----

    def _on_calculate_index(self):
        if not ensure_usable(self):
            return
        if not self._scene_folder or not self._current_dataset:
            QMessageBox.warning(self, "GeoVial", "Descarga una escena óptica primero.")
            return
        index_type = self.index_combo.currentData()
        out_path = os.path.join(tempfile.gettempdir(), f"geovial_{index_type.value}.tif")
        try:
            processing_service.calculate_index(index_type, self._scene_folder, self._current_dataset, out_path)
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error al calcular el índice: {ex}")
            return
        layer = QgsRasterLayer(out_path, index_type.value)
        QgsProject.instance().addMapLayer(layer)
        QMessageBox.information(self, "GeoVial", f"{index_type.value} calculado y cargado en el mapa.")

    def _on_extract_water(self):
        if not ensure_usable(self):
            return
        if not self._scene_folder or not self._current_dataset:
            QMessageBox.warning(self, "GeoVial", "Descarga una escena óptica primero.")
            return
        out_path = os.path.join(tempfile.gettempdir(), "geovial_agua.gpkg")
        try:
            processing_service.extract_water(self._scene_folder, self._current_dataset, out_path)
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error al extraer cuerpos de agua: {ex}")
            return
        layer = QgsVectorLayer(out_path, "Cuerpos de agua", "ogr")
        QgsProject.instance().addMapLayer(layer)
        QMessageBox.information(self, "GeoVial", "Cuerpos de agua extraídos y cargados en el mapa.")
