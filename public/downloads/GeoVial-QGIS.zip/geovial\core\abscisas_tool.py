"""Abscisas a puntos — puerto de AbscisasService.cs + abscisas_puntos.py.

Para cada eje, mide la distancia acumulada (abscisa) y la distancia
perpendicular de cada punto de points_layer, y actualiza EN SITIO los campos
NOMBRE / Abscisa_m / Abscisa_txt / OBS (igual que la versión de ArcGIS Pro).
Si hay varios ejes, el último procesado sobreescribe los campos de los
registros del filtro (mismo comportamiento que el original).
"""
from typing import Dict, Optional

from qgis.core import QgsVectorLayer
from qgis.PyQt.QtCore import QVariant
from shapely.geometry import Point

from . import geom_common as gc


def run(
    axes: Dict[str, QgsVectorLayer],
    points_layer: QgsVectorLayer,
    prefix: str = "PTO",
    campo_filtro: Optional[str] = None,
    valor_filtro: Optional[str] = None,
    log=print,
) -> int:
    fields = points_layer.fields()

    where = None
    if campo_filtro and valor_filtro not in (None, ""):
        idx = fields.indexOf(campo_filtro)
        if idx >= 0 and fields.field(idx).type() == QVariant.String:
            safe = str(valor_filtro).replace("'", "''")
            where = f"\"{campo_filtro}\" = '{safe}'"
        else:
            where = f"\"{campo_filtro}\" = {valor_filtro}"
        log(f"Filtro activo: {where}")
    else:
        log("Sin filtro — se procesarán todos los registros.")

    nom_len = max(len(prefix) + 5, 20)
    to_add = []
    for fname, ftype, flen in [
        ("NOMBRE", QVariant.String, nom_len),
        ("Abscisa_m", QVariant.Double, 0),
        ("Abscisa_txt", QVariant.String, 12),
        ("OBS", QVariant.String, 60),
    ]:
        if fields.indexOf(fname) < 0:
            from qgis.core import QgsField
            to_add.append(QgsField(fname, ftype, len=flen))
    if to_add:
        points_layer.dataProvider().addAttributes(to_add)
        points_layer.updateFields()
        fields = points_layer.fields()

    pts = gc.read_features(points_layer, where=where)
    log(f"Puntos leídos: {len(pts)}" + (f" (filtro: {where})" if where else ""))
    if not pts:
        raise ValueError("La capa de puntos no tiene geometrías válidas con el filtro aplicado.")

    idx_nombre = fields.indexOf("NOMBRE")
    idx_absc_m = fields.indexOf("Abscisa_m")
    idx_absc_txt = fields.indexOf("Abscisa_txt")
    idx_obs = fields.indexOf("OBS")

    points_layer.startEditing()
    try:
        for axis_name, axis_layer in axes.items():
            log(f"Procesando {axis_name}...")
            eje_g = gc.load_axis_geom(axis_layer)

            abscisas = {}
            distancias = {}
            for feat in pts:
                pt = Point(feat["geom"].centroid.x, feat["geom"].centroid.y) \
                    if feat["geom"].geom_type != "Point" else feat["geom"]
                abscisas[feat["fid"]] = gc.measure_abscissa(pt, eje_g)
                distancias[feat["fid"]] = gc.dist_to_axis(pt, eje_g)

            sorted_fids = sorted(abscisas, key=lambda fid: abscisas[fid])
            for i, fid in enumerate(sorted_fids):
                absc = abscisas[fid]
                dist = distancias[fid]
                nombre = f"{prefix}_{i + 1:03d}"
                obs = "Punto sobre el eje vial" if dist < 0.01 else f"Dist al eje: {dist:.2f} m"
                points_layer.changeAttributeValue(fid, idx_nombre, nombre)
                points_layer.changeAttributeValue(fid, idx_absc_m, absc)
                points_layer.changeAttributeValue(fid, idx_absc_txt, gc.format_abscissa(absc))
                points_layer.changeAttributeValue(fid, idx_obs, obs)
        points_layer.commitChanges()
    except Exception:
        points_layer.rollBack()
        raise

    log(f"RESUMEN: {len(pts)} puntos actualizados con {len(axes)} eje(s).")
    return len(pts)
