"""Chequeo de actualización disponible (puerto de CheckForUpdateAsync en
LicenseService.cs). Sin autoupdate: solo compara un número de build contra
https://geovialpro.com/version-qgis.json y avisa si hay una versión nueva.
"""
import threading
from dataclasses import dataclass
from typing import Optional

import requests

from .license_service import BACKEND_BASE_URL

# Incrementar a mano cada vez que se publica un geovial.zip nuevo en la web
# (junto con actualizar public/version-qgis.json en GeoVialWeb).
QGIS_BUILD_NUMBER = 1

_VERSION_URL = f"{BACKEND_BASE_URL}/version-qgis.json"
_HTTP_TIMEOUT = 5


@dataclass
class UpdateInfo:
    available: bool = False
    latest_version: str = ""
    download_url: str = ""
    notes: str = ""


NONE = UpdateInfo(available=False)

_cached: Optional[UpdateInfo] = None
_started = False
_lock = threading.Lock()


def _fetch() -> UpdateInfo:
    try:
        resp = requests.get(_VERSION_URL, timeout=_HTTP_TIMEOUT)
        if not resp.ok:
            return NONE
        data = resp.json()
        remote_build = int(data.get("buildNumber", 0))
        return UpdateInfo(
            available=remote_build > QGIS_BUILD_NUMBER,
            latest_version=data.get("version", ""),
            download_url=data.get("downloadUrl", ""),
            notes=data.get("notes", ""),
        )
    except Exception:
        return NONE


def kick_off_check_if_needed() -> None:
    """Lanza el chequeo en un hilo aparte (no bloquea la UI), una sola vez por sesión."""
    global _started
    with _lock:
        if _started:
            return
        _started = True

    def _run():
        global _cached
        _cached = _fetch()

    threading.Thread(target=_run, daemon=True).start()


def cached_update_info() -> Optional[UpdateInfo]:
    return _cached
