"""Cliente de la API USGS Machine-to-Machine (M2M), endpoint "stable".

Puerto 1:1 de UsgsM2mClient.cs: login-token, scene-search, download-options,
download-request, download-retrieve.

Docs: https://m2m.cr.usgs.gov/api/docs/json/
"""
from datetime import datetime
from typing import Iterable, List, Optional

import requests

from .models import DownloadItem, SceneResult, SearchCriteria

_BASE_URL = "https://m2m.cr.usgs.gov/api/api/json/stable/"


class UsgsApiError(Exception):
    pass


class UsgsM2mClient:
    def __init__(self):
        self._session = requests.Session()
        self._api_key: Optional[str] = None

    @property
    def is_logged_in(self) -> bool:
        return bool(self._api_key)

    def _post(self, endpoint: str, payload: dict) -> dict:
        headers = {"X-Auth-Token": self._api_key} if self._api_key else {}
        resp = self._session.post(_BASE_URL + endpoint, json=payload, headers=headers, timeout=600)
        body = resp.json()
        if body.get("errorCode"):
            raise UsgsApiError(f"{body['errorCode']}: {body.get('errorMessage', 'Error desconocido')}")
        return body.get("data")

    # ---- Autenticación ----

    def login(self, username: str, application_token: str) -> None:
        data = self._post("login-token", {"username": username, "token": application_token})
        self._api_key = data
        if not self._api_key:
            raise UsgsApiError("No se recibió token de sesión. Verifica usuario y Application Token.")

    def logout(self) -> None:
        if not self.is_logged_in:
            return
        try:
            self._post("logout", {})
        except Exception:
            pass
        self._api_key = None

    # ---- Búsqueda de escenas ----

    def search_scenes(self, c: SearchCriteria) -> List[SceneResult]:
        payload = {
            "datasetName": c.dataset.dataset_name,
            "maxResults": c.max_results,
            "startingNumber": 1,
            "sceneFilter": {
                "spatialFilter": {
                    "filterType": "mbr",
                    "lowerLeft": {"latitude": c.min_lat, "longitude": c.min_lon},
                    "upperRight": {"latitude": c.max_lat, "longitude": c.max_lon},
                },
                "acquisitionFilter": {
                    "start": c.start_date.strftime("%Y-%m-%d"),
                    "end": c.end_date.strftime("%Y-%m-%d"),
                },
                "cloudCoverFilter": {"min": c.min_cloud, "max": c.max_cloud, "includeUnknown": False},
            },
        }
        data = self._post("scene-search", payload)
        results = []
        for r in (data or {}).get("results", []):
            results.append(SceneResult(
                dataset_name=c.dataset.dataset_name,
                entity_id=r.get("entityId"),
                display_id=r.get("displayId"),
                browse_url=_extract_browse_url(r),
                cloud_cover=_extract_cloud_cover(r),
                acquisition_date=_extract_acquisition_date(r),
                footprint_geojson=_extract_footprint(r),
            ))
        return results

    # ---- Descarga ----

    def get_download_options(self, dataset_name: str, entity_ids: Iterable[str]) -> List[DownloadItem]:
        data = self._post("download-options", {"datasetName": dataset_name, "entityIds": list(entity_ids)})
        items = []
        for o in data or []:
            available = o.get("available") in (True, "Y")
            items.append(DownloadItem(
                entity_id=o.get("entityId"),
                product_id=o.get("id"),
                product_name=o.get("productName"),
                file_size=o.get("filesize", 0) or 0,
                available=available,
            ))
        return items

    def request_downloads(self, products: Iterable[DownloadItem]) -> List[DownloadItem]:
        downloads = []
        for i, p in enumerate(products, start=1):
            downloads.append({
                "entityId": p.entity_id, "productId": p.product_id,
                "dataUse": "scientific", "label": str(i),
            })
        data = self._post("download-request", {"downloads": downloads, "label": "geovial"})
        ready = []
        for d in (data or {}).get("availableDownloads", []) or []:
            url = d.get("url")
            if url:
                ready.append(DownloadItem(url=url, available=True, product_name="available"))
        return ready

    def retrieve_downloads(self) -> List[str]:
        data = self._post("download-retrieve", {"label": "geovial"})
        return [d["url"] for d in (data or {}).get("available", []) or [] if d.get("url")]


def _extract_browse_url(r: dict) -> Optional[str]:
    for b in r.get("browse", []) or []:
        url = b.get("thumbnailPath") or b.get("browsePath")
        if url:
            return url
    return None


def _extract_cloud_cover(r: dict) -> float:
    cc = r.get("cloudCover")
    try:
        return float(cc)
    except (TypeError, ValueError):
        return float("nan")


def _extract_acquisition_date(r: dict) -> datetime:
    tc = r.get("temporalCoverage") or {}
    for value in (tc.get("startDate"), r.get("publishDate")):
        if value:
            try:
                return datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError:
                continue
    return datetime.min


def _extract_footprint(r: dict) -> Optional[str]:
    import json
    for key in ("spatialCoverage", "spatialBounds"):
        if r.get(key):
            return json.dumps(r[key])
    return None
