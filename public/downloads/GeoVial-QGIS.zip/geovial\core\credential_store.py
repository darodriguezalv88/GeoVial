"""Credenciales cifradas (DPAPI) de los proveedores CDSE/USGS.

Puerto de CredentialStore.cs. Mismo archivo que el add-in de ArcGIS Pro
(%APPDATA%\\SatImageryAddin\\creds.bin) para no pedir las credenciales de
nuevo si el usuario ya las guardó desde la otra plataforma.
"""
import json
import os
from typing import Optional, Tuple

from . import dpapi
from .dataset_catalog import Provider

_ENTROPY = b"SatImageryAddin::v1"


def _folder() -> str:
    return os.path.join(os.environ["APPDATA"], "SatImageryAddin")


def _file_path() -> str:
    return os.path.join(_folder(), "creds.bin")


def _load_all() -> dict:
    path = _file_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "rb") as f:
            enc = f.read()
        raw = dpapi.unprotect(enc, _ENTROPY)
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return {}


def _save_all(data: dict) -> None:
    os.makedirs(_folder(), exist_ok=True)
    raw = json.dumps(data).encode("utf-8")
    enc = dpapi.protect(raw, _ENTROPY)
    with open(_file_path(), "wb") as f:
        f.write(enc)


def save(provider: Provider, user: str, secret: str) -> None:
    data = _load_all()
    data[provider.value] = {"User": user, "Secret": secret}
    _save_all(data)


def try_load(provider: Provider) -> Optional[Tuple[str, str]]:
    entry = _load_all().get(provider.value)
    if not entry or not entry.get("User"):
        return None
    return entry["User"], entry.get("Secret")


def has_saved(provider: Provider) -> bool:
    return provider.value in _load_all()


def clear(provider: Provider) -> None:
    data = _load_all()
    if data.pop(provider.value, None) is not None:
        _save_all(data)
