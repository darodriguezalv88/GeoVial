"""Cliente de Copernicus Data Space Ecosystem (CDSE) para Sentinel-2.

Puerto 1:1 de CdseClient.cs. Autenticación OAuth2 "password grant" contra
Keycloak (cliente público cdse-public). Búsqueda: OData del catálogo.
Descarga: endpoint zipper con token Bearer.

Docs: https://documentation.dataspace.copernicus.eu/APIs/OData.html
"""
import time
from typing import Callable, List, Optional

import requests

from .dataset_catalog import Provider
from .models import SceneResult, SearchCriteria

_TOKEN_URL = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
_CATALOG_URL = "https://catalogue.dataspace.copernicus.eu/odata/v1/Products"
_ZIPPER_URL = "https://zipper.dataspace.copernicus.eu/odata/v1/Products"


class CdseApiError(Exception):
    pass


class CdseClient:
    def __init__(self):
        self._session = requests.Session()
        self._access_token = None
        self._refresh_token = None
        self._access_expires_at = 0.0
        self._user = self._password = None

    @property
    def is_logged_in(self) -> bool:
        return bool(self._refresh_token)

    # ---- Autenticación ----

    def login(self, user: str, password: str) -> None:
        self._user, self._password = user, password
        self._request_token(use_refresh=False)

    def logout(self) -> None:
        self._access_token = self._refresh_token = None
        self._access_expires_at = 0.0

    def _request_token(self, use_refresh: bool) -> None:
        if use_refresh and self._refresh_token:
            form = {
                "grant_type": "refresh_token",
                "refresh_token": self._refresh_token,
                "client_id": "cdse-public",
            }
        else:
            form = {
                "grant_type": "password",
                "username": self._user,
                "password": self._password,
                "client_id": "cdse-public",
            }

        resp = self._session.post(_TOKEN_URL, data=form)
        if not resp.ok:
            if use_refresh:
                self._request_token(False)
                return
            detail = resp.json().get("error_description", resp.text) if _is_json(resp) else resp.text
            raise CdseApiError(f"No se pudo autenticar en Copernicus: {detail}")

        body = resp.json()
        self._access_token = body["access_token"]
        self._refresh_token = body.get("refresh_token", self._refresh_token)
        expires = body.get("expires_in", 600)
        self._access_expires_at = time.time() + expires - 30  # margen

    def _valid_token(self) -> str:
        if not self._access_token:
            raise CdseApiError("Sesión de Copernicus no iniciada.")
        if time.time() >= self._access_expires_at:
            self._request_token(use_refresh=True)
        return self._access_token

    # ---- Búsqueda (OData) ----

    def search_scenes(self, c: SearchCriteria) -> List[SceneResult]:
        wkt = (
            f"POLYGON(({c.min_lon} {c.min_lat},{c.max_lon} {c.min_lat},"
            f"{c.max_lon} {c.max_lat},{c.min_lon} {c.max_lat},{c.min_lon} {c.min_lat}))"
        )
        filters = [
            f"Collection/Name eq '{c.dataset.cdse_collection}'",
            f"OData.CSC.Intersects(area=geography'SRID=4326;{wkt}')",
            f"ContentDate/Start gt {c.start_date:%Y-%m-%d}T00:00:00.000Z",
            f"ContentDate/Start lt {c.end_date:%Y-%m-%d}T23:59:59.999Z",
        ]
        if c.dataset.cdse_product_type:
            filters.append(
                "Attributes/OData.CSC.StringAttribute/any(att:att/Name eq 'productType' "
                f"and att/OData.CSC.StringAttribute/Value eq '{c.dataset.cdse_product_type}')"
            )
        filters.append(
            "Attributes/OData.CSC.DoubleAttribute/any(att:att/Name eq 'cloudCover' "
            f"and att/OData.CSC.DoubleAttribute/Value le {c.max_cloud})"
        )

        filter_str = " and ".join(filters)
        url = (
            f"{_CATALOG_URL}?$filter={requests.utils.quote(filter_str)}"
            f"&$orderby=ContentDate/Start desc&$top={c.max_results}&$expand=Attributes"
        )

        resp = self._session.get(url)
        if not resp.ok:
            raise CdseApiError(f"Error en la búsqueda CDSE: {resp.text}")

        results = []
        for p in resp.json().get("value", []):
            results.append(SceneResult(
                provider=Provider.CDSE,
                entity_id=p.get("Id"),
                display_id=p.get("Name"),
                dataset_name=c.dataset.cdse_collection,
                cloud_cover=_extract_cloud(p),
                acquisition_date=_extract_date(p),
                browse_url=_quicklook_url(p.get("Id")),
                footprint_geojson=_dumps_or_none(p.get("GeoFootprint")),
            ))
        return results

    # ---- Descarga ----

    def download_product(
        self, product_id: str, product_name: str, dest_folder: str,
        on_progress: Optional[Callable[[float], None]] = None,
    ) -> str:
        import os
        token = self._valid_token()
        os.makedirs(dest_folder, exist_ok=True)

        url = f"{_ZIPPER_URL}({product_id})/$value"
        headers = {"Authorization": f"Bearer {token}"}

        with self._session.get(url, headers=headers, stream=True) as resp:
            resp.raise_for_status()
            safe_name = product_name or product_id
            if not safe_name.lower().endswith(".zip"):
                safe_name += ".zip"
            dest_path = os.path.join(dest_folder, _sanitize(safe_name))

            total = int(resp.headers.get("Content-Length", -1))
            read_total = 0
            with open(dest_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=81920):
                    if not chunk:
                        continue
                    f.write(chunk)
                    read_total += len(chunk)
                    if on_progress:
                        on_progress(read_total * 100.0 / total if total > 0 else -1)
            if on_progress:
                on_progress(100)
            return dest_path


def _is_json(resp) -> bool:
    try:
        resp.json()
        return True
    except Exception:
        return False


def _extract_cloud(p: dict) -> float:
    for a in p.get("Attributes", []) or []:
        if a.get("Name") == "cloudCover":
            return a.get("Value", float("nan"))
    return float("nan")


def _extract_date(p: dict):
    from datetime import datetime
    start = (p.get("ContentDate") or {}).get("Start")
    if not start:
        return datetime.min
    try:
        return datetime.fromisoformat(start.replace("Z", "+00:00"))
    except ValueError:
        return datetime.min


def _quicklook_url(product_id: Optional[str]) -> Optional[str]:
    if not product_id:
        return None
    return f"{_ZIPPER_URL}({product_id})/Products(Quicklook)/$value"


def _dumps_or_none(value) -> Optional[str]:
    if value is None:
        return None
    import json
    return json.dumps(value)


def _sanitize(name: str) -> str:
    for ch in '<>:"/\\|?*':
        name = name.replace(ch, "_")
    return name
