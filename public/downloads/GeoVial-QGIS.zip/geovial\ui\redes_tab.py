from qgis.core import QgsMapLayerProxyModel, QgsProject
from qgis.PyQt.QtWidgets import (
    QDoubleSpinBox, QFormLayout, QGroupBox, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from ..core import redes_tool
from ..core.redes_tool import RedLayerSpec
from .layer_rows import FilterableLayerListWidget, NamedLayerListWidget
from .license_gate import ensure_usable


class RedesTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)

        box = QGroupBox("Ejes / alternativas")
        box_layout = QVBoxLayout(box)
        self.axes_widget = NamedLayerListWidget(QgsMapLayerProxyModel.LineLayer)
        box_layout.addWidget(self.axes_widget)
        layout.addWidget(box)

        hs_box = QGroupBox("Red HS (alcantarillado sanitario)")
        hs_layout = QVBoxLayout(hs_box)
        self.hs_widget = FilterableLayerListWidget(QgsMapLayerProxyModel.LineLayer)
        hs_layout.addWidget(self.hs_widget)
        layout.addWidget(hs_box)

        hc_box = QGroupBox("Red HC (alcantarillado combinado/pluvial)")
        hc_layout = QVBoxLayout(hc_box)
        self.hc_widget = FilterableLayerListWidget(QgsMapLayerProxyModel.LineLayer)
        hc_layout.addWidget(self.hc_widget)
        layout.addWidget(hc_box)

        form_box = QGroupBox("Parámetros")
        form = QFormLayout(form_box)
        self.buffer_spin = QDoubleSpinBox()
        self.buffer_spin.setRange(1, 1000)
        self.buffer_spin.setValue(25)
        self.buffer_spin.setSuffix(" m")
        form.addRow("Buffer (corredor):", self.buffer_spin)
        layout.addWidget(form_box)

        run_btn = QPushButton("Calcular cruces con redes existentes")
        run_btn.clicked.connect(self._on_run)
        layout.addWidget(run_btn)
        layout.addStretch(1)

    def _on_run(self):
        if not ensure_usable(self):
            return
        axes = self.axes_widget.values()
        if not axes:
            QMessageBox.warning(self, "GeoVial", "Agrega al menos un eje.")
            return

        redes = {
            "HS": [RedLayerSpec(layer, campo, valor) for layer, campo, valor in self.hs_widget.values()],
            "HC": [RedLayerSpec(layer, campo, valor) for layer, campo, valor in self.hc_widget.values()],
        }
        if not redes["HS"] and not redes["HC"]:
            QMessageBox.warning(self, "GeoVial", "Agrega al menos una capa de red (HS o HC).")
            return

        try:
            points_layer, lines_layer = redes_tool.run(
                axes, redes, buffer_m=self.buffer_spin.value(), log=print,
            )
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error: {ex}")
            return

        project = QgsProject.instance()
        project.addMapLayer(lines_layer)
        project.addMapLayer(points_layer)
        QMessageBox.information(
            self, "GeoVial",
            f"{lines_layer.featureCount()} tramo(s) de red y {points_layer.featureCount()} cruce(s) cargados al mapa.",
        )
