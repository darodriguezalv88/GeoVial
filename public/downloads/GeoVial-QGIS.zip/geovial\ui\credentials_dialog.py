from qgis.PyQt.QtWidgets import QDialog, QFormLayout, QLineEdit, QDialogButtonBox, QLabel, QVBoxLayout

from ..core.dataset_catalog import Provider
from ..core import credential_store


class CredentialsDialog(QDialog):
    """Pide usuario+contraseña (CDSE) o usuario+Application Token (USGS)."""

    def __init__(self, provider: Provider, parent=None):
        super().__init__(parent)
        self.provider = provider
        is_cdse = provider == Provider.CDSE
        self.setWindowTitle("Credenciales " + ("Copernicus Data Space" if is_cdse else "USGS EROS"))

        layout = QVBoxLayout(self)
        if is_cdse:
            layout.addWidget(QLabel("Cuenta gratuita en dataspace.copernicus.eu"))
        else:
            layout.addWidget(QLabel("Usuario + Application Token de ers.cr.usgs.gov (Profile > Settings)"))

        form = QFormLayout()
        layout.addLayout(form)

        saved = credential_store.try_load(provider)
        self.user_edit = QLineEdit(saved[0] if saved else "")
        self.secret_edit = QLineEdit(saved[1] if saved else "")
        if is_cdse:
            self.secret_edit.setEchoMode(QLineEdit.Password)

        form.addRow("Usuario / email:", self.user_edit)
        form.addRow("Contraseña / Token:" if is_cdse else "Application Token:", self.secret_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def values(self):
        return self.user_edit.text().strip(), self.secret_edit.text().strip()

    def save(self):
        user, secret = self.values()
        credential_store.save(self.provider, user, secret)
