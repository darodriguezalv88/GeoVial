from qgis.PyQt.QtWidgets import (
    QDockWidget, QHBoxLayout, QLabel, QPushButton, QTabWidget, QVBoxLayout, QWidget,
)

from ..core import license_service
from .abscisas_tab import AbscisasTab
from .bridge_tab import BridgeTab
from .carto25k_tab import Carto25kTab
from .drainage_tab import DrainageTab
from .license_dialog import LicenseDialog
from .redes_tab import RedesTab
from .satellite_tab import SatelliteTab


class GeoVialDock(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("GeoVial", parent)
        self.iface = iface

        container = QWidget()
        self.setWidget(container)
        layout = QVBoxLayout(container)

        # --- Licencia ---
        self.license_frame = QWidget()
        self.license_frame.setAutoFillBackground(True)
        license_row = QHBoxLayout(self.license_frame)
        license_row.setContentsMargins(8, 6, 8, 6)
        self.license_label = QLabel()
        self.license_label.setWordWrap(True)
        self.license_btn = QPushButton("Activar / ver licencia…")
        self.license_btn.setStyleSheet("font-weight: bold;")
        self.license_btn.clicked.connect(self._open_license_dialog)
        license_row.addWidget(self.license_label, 1)
        license_row.addWidget(self.license_btn)
        layout.addWidget(self.license_frame)
        self._refresh_license_label()

        # --- Pestañas de herramientas ---
        tabs = QTabWidget()
        tabs.addTab(SatelliteTab(iface), "Satelital")
        tabs.addTab(AbscisasTab(), "Abscisas")
        tabs.addTab(DrainageTab(), "Drenaje")
        tabs.addTab(BridgeTab(), "Puentes")
        tabs.addTab(RedesTab(), "Redes")
        tabs.addTab(Carto25kTab(), "Carto25k")
        layout.addWidget(tabs)

    # ---- Licencia ----

    def _refresh_license_label(self):
        status = license_service.get_status()
        self.license_label.setText(f"<b>Licencia: {status.status_label}</b><br>{status.summary}")
        if status.licensed:
            bg = "#d4edda"
        elif status.trial_days_remaining > 0:
            bg = "#fff3cd"
        else:
            bg = "#f8d7da"
        self.license_frame.setStyleSheet(f"background-color: {bg}; border-radius: 4px;")

    def _open_license_dialog(self):
        LicenseDialog(self).exec_()
        self._refresh_license_label()
