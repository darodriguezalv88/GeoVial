"""Utilidades geométricas compartidas por las herramientas de obras
(abscisas, drenaje transversal, puentes, redes existentes).

Puerto genérico de los patrones repetidos en los scripts arcpy originales
(SearchCursor + geometría + Intersect/Buffer/Dissolve) usando Shapely para
el álgebra geométrica y la API de QGIS solo para leer/escribir capas.
"""
import math
from typing import Iterable, List, Optional, Union

from qgis.core import (
    QgsCoordinateTransform, QgsFeature, QgsField, QgsGeometry, QgsProject, QgsVectorLayer,
)
from qgis.PyQt.QtCore import QVariant
from shapely import wkb as shapely_wkb
from shapely.geometry import LineString, MultiLineString, MultiPolygon, Point, Polygon
from shapely.ops import unary_union

AxisGeom = Union[LineString, List[LineString]]


def dist2(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def format_abscissa(m: float) -> str:
    km = int(m // 1000)
    rem = int(round(m % 1000))
    if rem == 1000:
        km += 1
        rem = 0
    return f"K{km}+{rem:03d}"


def to_shapely(qgeom: QgsGeometry):
    return shapely_wkb.loads(bytes(qgeom.asWkb()))


def to_qgis_geom(sgeom) -> QgsGeometry:
    geom = QgsGeometry()
    geom.fromWkb(sgeom.wkb)
    return geom


def build_where(layer: QgsVectorLayer, campo: str, valor) -> str:
    idx = layer.fields().indexOf(campo)
    if idx >= 0 and layer.fields().field(idx).type() != QVariant.String:
        return f'"{campo}" = {valor}'
    safe = str(valor).replace("'", "''")
    return f'"{campo}" = \'{safe}\''


def read_features(layer: QgsVectorLayer, where: Optional[str] = None):
    """Devuelve [{'fid': int, 'attrs': {...}, 'geom': shapely}, ...]."""
    field_names = [f.name() for f in layer.fields()]
    request = None
    if where:
        from qgis.core import QgsFeatureRequest
        request = QgsFeatureRequest().setFilterExpression(where)
    feats = layer.getFeatures(request) if request is not None else layer.getFeatures()
    out = []
    for f in feats:
        geom = f.geometry()
        if geom is None or geom.isEmpty():
            continue
        out.append({"fid": f.id(), "attrs": dict(zip(field_names, f.attributes())), "geom": to_shapely(geom)})
    return out


def read_features_in_crs(layer: QgsVectorLayer, target_crs, where: Optional[str] = None):
    """Como read_features, pero reproyecta cada geometría a target_crs si el
    CRS de la capa difiere (equivalente a arcpy.management.Project cuando
    difieren los SR de eje y drenaje)."""
    feats = read_features(layer, where=where)
    if layer.crs() == target_crs:
        return feats
    transform = QgsCoordinateTransform(layer.crs(), target_crs, QgsProject.instance())
    for feat in feats:
        qgeom = to_qgis_geom(feat["geom"])
        qgeom.transform(transform)
        feat["geom"] = to_shapely(qgeom)
    return feats


def load_axis_geom(layer: QgsVectorLayer) -> AxisGeom:
    """Une las geometrías de todas las features del eje. Si hay una sola parte,
    devuelve la LineString directa; si hay varias (tramos con vacíos), devuelve
    la lista de segmentos — igual que 'eje_geoms' en los scripts arcpy."""
    parts = []
    for feat in read_features(layer):
        g = feat["geom"]
        if isinstance(g, MultiLineString):
            parts.extend(list(g.geoms))
        elif isinstance(g, LineString):
            parts.append(g)
    return parts[0] if len(parts) == 1 else parts


def measure_abscissa(pt: Point, eje: AxisGeom) -> float:
    """Distancia acumulada desde el inicio del eje hasta la proyección de pt.
    Si el eje viene como varios segmentos, usa el segmento más cercano y le
    suma la longitud acumulada de los segmentos anteriores (mismo criterio
    que _medir_abscisa en los scripts originales)."""
    if isinstance(eje, list):
        cum = 0.0
        best_d = float("inf")
        best_a = 0.0
        for seg in eje:
            d = seg.distance(pt)
            if d < best_d:
                best_d = d
                best_a = cum + seg.project(pt)
            cum += seg.length
        return best_a
    return eje.project(pt)


def dist_to_axis(pt: Point, eje: AxisGeom) -> float:
    if isinstance(eje, list):
        return min(seg.distance(pt) for seg in eje)
    return eje.distance(pt)


def explode_lines(geom) -> List[LineString]:
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, LineString):
        return [geom]
    if isinstance(geom, MultiLineString):
        return list(geom.geoms)
    if geom.geom_type == "GeometryCollection":
        out = []
        for g in geom.geoms:
            out.extend(explode_lines(g))
        return out
    return []


def explode_polygons(geom) -> List[Polygon]:
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, Polygon):
        return [geom]
    if isinstance(geom, MultiPolygon):
        return list(geom.geoms)
    if geom.geom_type == "GeometryCollection":
        out = []
        for g in geom.geoms:
            out.extend(explode_polygons(g))
        return out
    return []


def buffer_dissolved(layer: QgsVectorLayer, buffer_m: float) -> Polygon:
    """Buffer de todas las líneas de layer, disuelto en un solo polígono
    (equivalente a arcpy.analysis.Buffer con dissolve_option=ALL)."""
    geoms = [feat["geom"].buffer(buffer_m, cap_style="round") for feat in read_features(layer)]
    return unary_union(geoms)


def dissolve_singlepart(polys: Iterable[Polygon]) -> List[Polygon]:
    """Disuelve solapes/duplicados y devuelve una lista de polígonos
    single-part (equivalente a arcpy.management.Dissolve multi_part=SINGLE_PART)."""
    merged = unary_union(list(polys))
    return explode_polygons(merged)


def make_memory_layer(geom_type: str, crs, name: str, fields: List[tuple]) -> QgsVectorLayer:
    """fields: lista de (nombre, QVariant.Type, longitud_opcional)."""
    layer = QgsVectorLayer(f"{geom_type}?crs={crs.authid()}", name, "memory")
    provider = layer.dataProvider()
    qfields = []
    for spec in fields:
        fname, ftype = spec[0], spec[1]
        flen = spec[2] if len(spec) > 2 and spec[2] else 0
        qfields.append(QgsField(fname, ftype, len=flen or 0))
    provider.addAttributes(qfields)
    layer.updateFields()
    return layer


def add_feature(layer: QgsVectorLayer, sgeom, attrs: list):
    feat = QgsFeature(layer.fields())
    feat.setGeometry(to_qgis_geom(sgeom))
    feat.setAttributes(attrs)
    layer.dataProvider().addFeatures([feat])


TEXT = QVariant.String
DOUBLE = QVariant.Double
LONGI = QVariant.LongLong
