"""Persistencia del estado de licencia, cifrada con DPAPI (CurrentUser).

Puerto de LicenseStore.cs. Mismo archivo que usa el add-in de ArcGIS Pro
(%APPDATA%\\GeoVial\\license.dat) para que activar la licencia en una
plataforma la deje disponible también en la otra, en el mismo equipo.
"""
import json
import os
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional

from . import dpapi

_ENTROPY = b"GeoVial::License::v1"


def _folder() -> str:
    return os.path.join(os.environ["APPDATA"], "GeoVial")


def _file_path() -> str:
    return os.path.join(_folder(), "license.dat")


@dataclass
class LicenseState:
    first_run_utc: Optional[str] = None
    license_key: Optional[str] = None
    last_validated_utc: Optional[str] = None
    last_validation_result: bool = False
    activated_utc: Optional[str] = None


def load() -> LicenseState:
    path = _file_path()
    if not os.path.exists(path):
        return LicenseState()
    try:
        with open(path, "rb") as f:
            enc = f.read()
        raw = dpapi.unprotect(enc, _ENTROPY)
        data = json.loads(raw.decode("utf-8"))
        return LicenseState(**{k: data.get(k) for k in LicenseState.__dataclass_fields__})
    except Exception:
        return LicenseState()


def save(state: LicenseState) -> None:
    os.makedirs(_folder(), exist_ok=True)
    raw = json.dumps(asdict(state)).encode("utf-8")
    enc = dpapi.protect(raw, _ENTROPY)
    with open(_file_path(), "wb") as f:
        f.write(enc)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
