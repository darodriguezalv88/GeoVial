from qgis.core import QgsMapLayerProxyModel, QgsProject
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtWidgets import (
    QDoubleSpinBox, QFormLayout, QGroupBox, QLineEdit, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from ..core import drainage_tool
from .layer_rows import NamedLayerListWidget
from .license_gate import ensure_usable


class DrainageTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)

        box = QGroupBox("Ejes / alternativas")
        box_layout = QVBoxLayout(box)
        self.axes_widget = NamedLayerListWidget(QgsMapLayerProxyModel.LineLayer)
        box_layout.addWidget(self.axes_widget)
        layout.addWidget(box)

        form_box = QGroupBox("Drenaje")
        form = QFormLayout(form_box)
        self.drainage_combo = QgsMapLayerComboBox()
        self.drainage_combo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Red de drenaje:", self.drainage_combo)

        self.campo_edit = QLineEdit("ESTADO_DRENAJE")
        form.addRow("Campo (cauce permanente):", self.campo_edit)
        self.valor_edit = QLineEdit("5101")
        form.addRow("Valor:", self.valor_edit)

        self.buffer_spin = QDoubleSpinBox()
        self.buffer_spin.setRange(1, 1000)
        self.buffer_spin.setValue(25)
        self.buffer_spin.setSuffix(" m")
        form.addRow("Buffer (corredor):", self.buffer_spin)

        layout.addWidget(form_box)

        run_btn = QPushButton("Calcular obras de drenaje transversal")
        run_btn.clicked.connect(self._on_run)
        layout.addWidget(run_btn)
        layout.addStretch(1)

    def _on_run(self):
        if not ensure_usable(self):
            return
        axes = self.axes_widget.values()
        drainage_layer = self.drainage_combo.currentLayer()
        if not axes:
            QMessageBox.warning(self, "GeoVial", "Agrega al menos un eje.")
            return
        if drainage_layer is None:
            QMessageBox.warning(self, "GeoVial", "Selecciona la red de drenaje.")
            return
        valor = self.valor_edit.text().strip()
        try:
            valor = float(valor) if valor.replace(".", "", 1).isdigit() else valor
        except ValueError:
            pass
        try:
            points_layer, lines_layer, buffer_layers = drainage_tool.run(
                axes, drainage_layer,
                campo=self.campo_edit.text().strip() or "ESTADO_DRENAJE",
                valor=valor,
                buffer_m=self.buffer_spin.value(),
                log=print,
            )
        except Exception as ex:
            QMessageBox.critical(self, "GeoVial", f"Error: {ex}")
            return

        project = QgsProject.instance()
        project.addMapLayer(lines_layer)
        project.addMapLayer(points_layer)
        for buf_layer in buffer_layers.values():
            project.addMapLayer(buf_layer)
        QMessageBox.information(
            self, "GeoVial",
            f"{points_layer.featureCount()} obra(s) de drenaje transversal calculadas y cargadas al mapa.",
        )
