"""Descarga por HTTP con progreso y extracción de .tar/.tar.gz/.zip (puerto de DownloadService.cs)."""
import os
import re
import shutil
import tarfile
import zipfile
from typing import Callable, Optional
from urllib.parse import urlparse

import requests


def download_file(
    url: str,
    dest_folder: str,
    on_progress: Optional[Callable[[float], None]] = None,
    headers: Optional[dict] = None,
) -> str:
    os.makedirs(dest_folder, exist_ok=True)
    with requests.get(url, stream=True, timeout=None, headers=headers) as resp:
        resp.raise_for_status()
        filename = _resolve_filename(resp, url)
        dest_path = os.path.join(dest_folder, filename)

        total = int(resp.headers.get("Content-Length", -1))
        read_total = 0
        with open(dest_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=81920):
                if not chunk:
                    continue
                f.write(chunk)
                read_total += len(chunk)
                if on_progress:
                    on_progress(read_total * 100.0 / total if total > 0 else -1)
        if on_progress:
            on_progress(100)
        return dest_path


def _resolve_filename(resp, url: str) -> str:
    cd = resp.headers.get("Content-Disposition", "")
    m = re.search(r'filename="?([^";]+)"?', cd)
    if m:
        return m.group(1)
    return os.path.basename(urlparse(url).path) or "download.bin"


def extract_archive(archive_path: str, dest_folder: str) -> str:
    os.makedirs(dest_folder, exist_ok=True)
    lower = archive_path.lower()
    if lower.endswith(".zip"):
        with zipfile.ZipFile(archive_path) as z:
            z.extractall(dest_folder)
    elif lower.endswith(".tar.gz") or lower.endswith(".tgz") or lower.endswith(".tar"):
        with tarfile.open(archive_path) as t:
            t.extractall(dest_folder)
    else:
        shutil.copy(archive_path, dest_folder)
    return dest_folder
